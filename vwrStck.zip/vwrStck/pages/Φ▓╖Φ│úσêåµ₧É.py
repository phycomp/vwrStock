'''
買點: 用綜合分析會顯示True 
量大收紅
量縮價不跌
三日均價由下往上
三日均價大於六日均價
賣點: 用綜合分析會顯示False
量大收黑
量縮價跌
三日均價由上往下
三日均價小於六日均價
快速查詢法:
在 TERMINAL 裡面打指令
twstock -b 股票代碼 
打好後 按Enter鍵
舉例:
twstock -b 1215
買點: Buy 
賣點: Sell
'''

from streamlit import sidebar, multiselect, radio as stRadio, text_input
from twstock import Stock, BestFourPoint
from stUtil import rndrCode

趣股={'2330':'台積電', '1215':'群峰'}
股欄=[股碼 for 股碼 in 趣股.keys()]
MENU, 表單=[], ['買賣分析', '', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
elif menu==MENU[0]: #買賣分析
  pass
for 股碼 in 趣股:
  個股 = Stock(股碼)   #在('')裡面打 股票代碼
  b = BestFourPoint(個股)

  buy = b.best_four_point_to_buy() #買點分析
  sell = b.best_four_point_to_sell() #賣點分析
  綜合 = b.best_four_point() #綜合分析 建議直接用這個 會比較快
  rndrCode([f'個股->{趣股.get(股碼)}', f'買->{buy}', f'賣->{sell}', f"分析結果->{綜合}"])
