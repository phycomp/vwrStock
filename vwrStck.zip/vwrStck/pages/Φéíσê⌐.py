from pandas import DataFrame, read_html, read_csv   #
from datetime import datetime, timedelta
from io import StringIO
from stUtil import rndrCode
from requests import get as rqstGET
from streamlit import sidebar, multiselect, radio as stRadio, text_input, session_state
from utilStck import 網頁股資, 計算殖率
from 計算殖率 import 殖利率
from 股件 import TwPrice, 上市股價, 得股息, 營益分析

股欄=['有價證券代號及名稱', '國際證券辨識號碼(ISIN Code)', '上市日', '市場別', '產業別', 'CFICode', '備註']
#股欄II=['股價日期', '證券代號', '證券名稱', '收盤價']
股欄2=['股價日期', '證券代號', '證券名稱', '成交股數', '成交筆數', '成交金額', '開盤價', '最高價', '最低價', '收盤價', '漲跌(+/-)', '漲跌價差', '本益比']
MENU, 表單=[], ['殖利率', '股利', '股價', '股息', '營益分析']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  欄股=multiselect('股市欄位', 股欄2, default=股欄2[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[4]: #
  年=2025
  營益分析(年)
elif menu==MENU[3]: #
  股息 = 得股息('0050')
  股息
  #rndrCode(股息)
elif menu==MENU[2]: #
  今日=datetime.today().date()
  前日=今日-timedelta(days=7)
  rndrCode(前日)
  try:
    股價=session_state[f'股價{前日}']#=TwPrice('20250520', '上市')
  except: 股價=session_state[f'股價{前日}']=上市股價(前日)#TwPrice(今日, '上市')
  #[]
  #rndrCode(股價.columns)
  有值=股價[~股價['本益比'].eq(0)]#.all(axis=1)#astype(str).str.nonzero()
  有值[欄股]
  #股價[股價['本益比'].astype(str).str.nonzero()]
  #股價[][欄股]
  #rndrCode(股價)
elif menu==MENU[1]: #
  pass
  股利址='https://tw.stock.yahoo.com/quote/0050/dividend'
  try: 股利資=session_state['股利資']
  except: 股利資=session_state['股利資']=網頁股資(股利址)
  #from streamlit.components.v1 import html, iframe
  股利區塊=股利資.find_all('span')
  rndrCode(['股利區塊', 股利區塊])
  #html(股利資)
  #iframe(股利資, width='500')
  #rndrCode(股利資)
  #區塊 = 網頁股資(股利址).find_all("span", class_="")
  #rndrCode(區塊)
  #股利 = float(區塊[28].string) #2021股利
elif menu==MENU[0]: #殖利率
  代碼股址='https://isin.twse.com.tw/isin/C_public.jsp?strMode=2'
  回溯=rqstGET(代碼股址)
  #股資框=read_csv(StringIO(回溯.text.replace("=", "")), header=None)    #["證券代號" in 碼 for 碼 in 回溯.text.split("\n")].index(True)-1)
  股資框=read_html(回溯.text, header=0)[0]
  股資框
  #股資 = read_html(代碼股址, encoding='big5hkscs', header=0)[0]
  #股資框=股資框.iloc[1:]
  #rndrCode(['長度=', len(股資框)])
  #rndrCode(股資框.columns)
  率殖=DataFrame()
  if 欄股:
    率殖['股代碼']=股資框['有價證券代號及名稱'].iloc[1:].str.split()
    率殖
    殖利率
    率殖['股代碼'].map(殖利率)
    #rndrCode(len())
