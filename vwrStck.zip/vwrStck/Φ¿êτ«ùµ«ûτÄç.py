from stUtil import rndrCode
from utilStck import 網頁股資, 計算殖率
def 殖利率(股代碼):
  '''
  股代碼
  '''
  股價址 = f'https://tw.stock.yahoo.com/quote/{股代碼}' #股價的網址
  股利址=f'https://tw.stock.yahoo.com/quote/{股代碼}/dividend' #股利的網址
  區塊 = 網頁股資(股價址).find_all("span")
  #rndrCode(['span=', 區塊])
  for 斯番 in 區塊:
    if 斯番.text == '成交':
      股價 = float(區塊[區塊.index(p) + 1].string) #股價

    span = 網頁股資(股利址).find_all("span", class_="")
    股利 = float(span[28].string) #2021股利
    計算殖率(股利, 股價)
  #try:
  #except:
    pass
