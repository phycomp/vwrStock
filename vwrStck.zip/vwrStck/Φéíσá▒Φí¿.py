import requests
from stUtil import rndrCode
import pandas as pd
import numpy as np

#http://mops.twse.com.tw/mops/web/ajax_t163sb06



def 財報表(year, season, exchange='sii', type='綜合損益表'):
    if year > 1911: year -= 1911
    if type == '綜合損益表': url = 'http://mops.twse.com.tw/mops/web/ajax_t163sb04'
    elif type == '資產負債表': url = 'http://mops.twse.com.tw/mops/web/ajax_t163sb05'
    elif type == '營益分析查詢彙總表': url = 'http://mops.twse.com.tw/mops/web/ajax_t163sb06'
    else: print('type does not match')

    # 一些參數：
    # TYPEK => 市場別
    # sii>上市
    # otc>上櫃
    # rotc>興櫃
    # pub>公開發行

    # year => 年度
    # season => 季別
    rndrCode(url)
    r = requests.post(url, {'encodeURIComponent':1, 'step':1, 'firstin':1, 'off':1, 'TYPEK':exchange, 'year':year, 'season':season})

    r.encoding = 'utf8'
    dfs = pd.read_html(r.text)
    for i, df in enumerate(dfs):
        df.columns = df.iloc[0]
        dfs[i] = df.iloc[1:]

    df = pd.concat(dfs).applymap(lambda x: x if x != '--' else np.nan)
    df = df[df['公司代號'] != '公司代號']
    df = df[~df['公司代號'].isnull()]
    if any(df.columns.str.contains("合計：")):
        df = df.loc[:, ~df.columns.str.contains("合計：")]
    return df
