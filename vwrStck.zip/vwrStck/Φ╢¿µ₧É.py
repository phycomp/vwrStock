from stUtil import rndrCode

def 趨析(趨勢, 關鍵字):
  資框 = 趨勢.interest_over_time(關鍵字)
  資框.plot(title='Python vs JavaScript Interest Over Time', figsize=(12, 6))
# Analyze geographic distribution
  for 關 in 關鍵字:
    geo_df = 趨勢.interest_by_region(關) # Get related queries
    related = 趨勢.related_queries(關) #Advanced Features
  #Search Categories and Locations
  # Find technology-related categories
    categories = 趨勢.categories(find='technology') # Output: [{'name': 'Computers & Electronics', 'id': '13'}, ...]

    locations = 趨勢.geo(find='york') # Search for locations [{'name': 'New York', 'id': 'US-NY'}, ...]

  # Use in queries
    資框 = 趨勢.interest_over_time(關, geo='US-NY',      # Found location ID
        cat='13')          # Found category ID
    
  #Real-time Trending Searches and News
  # Get current trending searches in the US
    trends = 趨勢.trending_now(geo='US')

  # Get trending searches with news articles
    trends_with_news = 趨勢.trending_now_by_rss(geo='US')
    rndrCode(trends_with_news[0])  # First trending topic
    rndrCode(trends_with_news[0].news[0])  # Associated news article

  # Get news articles for specific trending topics
    news = 趨勢.trending_now_news_by_ids(
        trends[0].news_tokens,  # News tokens from trending topic
        max_news=3)  # Number of articles to retrieve
    for article in news:
        rndrCode(f"Title: {article.title}")
        rndrCode(f"Source: {article.source}")
        rndrCode(f"URL: {article.url}\n")
  #Independent Historical Data for Multiple Keywords
    from trendspy import BatchPeriod

  # Unlike standard interest_over_time where data is normalized across all keywords,
  # trending_now_showcase_timeline provides independent data for each keyword
  # (up to 500+ keywords in a single request)

    keywords = ['AAPL', 'NVDA'] #, 'keyword500'

  # Get independent historical data
    整天趨勢 = 趨勢.trending_now_showcase_timeline(keywords, timeframe=BatchPeriod.Past24H) # 16-minute intervals


    整天趨勢.plot(subplots=True, layout=(5, 2), figsize=(15, 20), title="Independent Trend Lines") # Each keyword's data is normalized only to itself

  # Available time windows:
  # - Past4H:  ~30 points (8-minute intervals)
  # - Past24H: ~90 points (16-minute intervals)
  # - Past48H: ~180 points (16-minute intervals)
  # - Past7D:  ~42 points (4-hour intervals)
  #Geographic Analysis
  # Country-level data
    country_df=趨勢.interest_by_region('python')

  # State-level data for the US
    state_df=趨勢.interest_by_region(關, geo='US', resolution='REGION')

  # City-level data for California
    city_df=趨勢.interest_by_region(關, geo='US-CA', resolution='CITY')
  #Timeframe Formats
  #Standard API timeframes: 'now 1-H', 'now 4-H', 'today 1-m', 'today 3-m', 'today 12-m'
  #Custom intervals:
  #Short-term (< 8 days): 'now 123-H', 'now 72-H'
  #Long-term: 'today 45-d', 'today 90-d', 'today 18-m'
  #Date-based: '2024-02-01 10-d', '2024-03-15 3-m'
  #Date ranges: '2024-01-01 2024-12-31'
  #Hourly precision: '2024-03-25T12 2024-03-25T15' (for periods < 8 days)
  #All available data: 'all'
  #Multirange Interest Over Time
  #Compare search interest across different time periods and regions:

  # Compare different time periods
    timeframes = [ '2024-01-25 12-d',    # 12-day period
        '2024-06-20 23-d'     # 23-day period
    ]
    geo = ['US', 'GB']        # Compare US and UK

    資框 = 趨勢.interest_over_time(關, timeframe=timeframes, geo=geo)
#Note: When using multiple timeframes, they must maintain consistent resolution and the maximum timeframe cannot be more than twice the length of the minimum timeframe.

#Proxy Support
#TrendsPy supports the same proxy configuration as the requests library:

  趨勢 = Trends(proxy="http://user:pass@10.10.1.10:3128")
  趨勢 = Trends(proxy={ "http": "http://10.10.1.10:3128", "https": "http://10.10.1.10:1080" })
  趨勢.set_proxy("http://10.10.1.10:3128") # Configure proxy after initialization
