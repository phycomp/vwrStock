from twstock import Stock
from pandas import DataFrame
import plotly.express as e 

from streamlit import sidebar, multiselect, radio as stRadio, text_input
股欄=['日期', '成交股數', '成交量', '開盤價', '最高價', '最低價', '收盤價', '漲跌價差', '成交筆數']
#股資.columns = ['日期', '成交股數', '成交量', '開盤價', '最高價', '最低價', '收盤價', '漲跌價差', '成交筆數']
#data.columns = ['日期', '成交股數', '成交量', '開盤價', '最高價', '最低價', '收盤價', '漲跌價差', '成交筆數']
MENU, 表單=[], ['特定期間', '', '']	#, '錯綜複雜', '二十四節氣'
趣股={'2330':'台積電', '1215':'卜蜂', '0050':'元大50'}   #'1215':'群峰', 
多股=list(趣股.keys())
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  股=stRadio('表單', 多股, horizontal=True, index=0)
  欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
elif menu==MENU[0]: #特定期間
  for 股碼 in 趣股:
    個股 = Stock(股碼) #在('')裡面 打股票代碼
    股資 = 個股.fetch_31() #查最近一個月的資料
    股資框 = DataFrame(股資, columns=股欄)
    #股資.columns = 
    股資框

    股資 = 個股.fetch(2021, 6) #取出2021年6月的資料 查某年某月的資料
    股資框= DataFrame(股資, columns=股欄)
    股資框

    股資 = 個股.fetch_from(2021, 6) #取出2021年6月到現在的資料 查某年某月到現在 的資料
    股資 = DataFrame(股資, columns=股欄)

    圖 = e.line(data, x='日期', y='收盤價', title='1215卜蜂收盤價') #顯示收盤價的圖
    result.show()

    #顯示成交量的圖
    圖 = e.bar(data, x='日期', y='成交量', title='1215卜蜂成交量')
    plotly_chart(圖)
    result.show()
