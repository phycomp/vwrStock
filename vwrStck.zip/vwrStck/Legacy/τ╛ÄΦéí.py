from yfinance import Ticker
from pandas import read_html
from requests import get as rqstGET
from streamlit import sidebar, session_state, radio as stRadio, columns as stCLMN, text_area, text_input, multiselect
from streamlit import toggle as stToggle, markdown as stMarkdown #slider, dataframe, code as stCode, cache as stCache, 
# 必要步驟！告訴 python 你的標的股票是什麼

MENU, 表單=[], ['美股', '檔頭', '個美股', '繪圖']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
URL=['https://www.slickcharts.com/sp500', 'https://finance.yahoo.com/screener/predefined/most_actives?count=100&offset=0'] #, 'https://www.slickcharts.com/sp500' 貼上連結
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  url=stRadio('網址', URL, horizontal=True, index=0, key='網址')
  srch=text_input('搜尋', '')
if menu==len(表單):
  pass
elif menu==MENU[2]:
  import time
  股資 = Ticker('AAPL').info # 取得個股公司資料的語法，先測試一檔看看
  股資
  # 將 yfinance 有提供的數據項目取出存在 info_columns，它將會成為 stk_info_df 這張總表的欄位項目
  欄位 = list(股資.keys())
  # 創立一個名為 stk_info_df 的總表，用來存放所有股票的基本資料！其中 stk_list 是我們先前抓到的股票代碼喔！
  stk_info_df = DataFrame(index = stk_list.sort_values(), columns = 欄位)

  # 創立一個紀錄失敗股票的 list
  failed_list = []

  # 開始迴圈抓資料囉！
  for i in stk_info_df.index:
      try:
          # 打印出目前進度
          print('processing: ' + i)
          # 抓下來的資料暫存成 dictionary
          info_dict = yf.Ticker(i).info
          # 由於 yahoo finance 各檔股票所提供的欄位項目都不一致！所以這邊要針對每一檔股票分別取出欄位項目
          columns_included = list(info_dict.keys())
          # 因為在別檔公司裡有著 AAPL 裡所沒有的會計科目，因此要取兩家公司會計科目的交集
          intersect_columns = [x for x in info_columns if x in columns_included]
          # 有了該股欄位項目後，就可順利填入總表中相對應的位置
          stk_info_df.loc[i,intersect_columns] = list(pd.Series(info_dict)[intersect_columns].values)
          # 停一秒，再抓下一檔，避免對伺服器造成負擔而被鎖住
          time.sleep(1)
      except:
          failed_list.append(i)
          continue

  # 查看一下資料內容，然後儲存下來吧！
  stk_info_df.to_csv('')
elif menu==MENU[1]:
  # 貼上連結
  if url:
    headers = {"User-Agent" : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36'}
    request = rqstGET(url, headers = headers)
    股=read_html(request.text)[0]
    股清單=股.Symbol # 欄位『Symbol』就是股票代碼
    股清單=股.Symbol.apply(lambda x: x.replace('.', '-')) # 用 replace 將符號進行替換
    股清單
elif menu==MENU[1]:
  if url:
    股 = read_html(url)[0]
    股清單 = 股.Symbol # 欄位『Symbol』就是股票代碼
    股清單 = 股.Symbol.apply(lambda x: x.replace('.', '-')) # 用 replace 將符號進行替換
    股清單
elif menu==MENU[0]: #美股
  股 = Ticker('股票代碼') # 取得各種資料
  #stock.info # 取得公司資料
  股.financials # 取得損益表
  股.balance_sheet # 取得資產負債表
  股.cashflow # 取得現金流量表
  股.history # 取得價量資料＋股利發放資料＋股票分割資料
  if url:
    股 = read_html(url)[0]
    stk_list = 股.Symbol  # 欄位『Symbol』就是股票代碼
    stk_list

