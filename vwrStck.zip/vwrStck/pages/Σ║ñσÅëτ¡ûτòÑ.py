from backtesting import Backtest, Strategy #引入回測和交易策略功能
from stUtil import rndrCode
from pandas import read_csv, to_datetime
from backtesting.lib import crossover #引入判斷均線交會功能
from backtesting.test import SMA #引入繪製均線功能
from 交叉 import SmaCross
from streamlit import sidebar, multiselect, radio as stRadio, text_input

MENU, 表單=[], ['交叉點', '', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  #欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
elif menu==MENU[0]:     #交叉點
  stock="TSLA" #設定要測試的股票標的名稱
  資框=read_csv(f"data/{stock}.csv", index_col=0) #pandas讀取資料，並將第1欄作為索引欄
  資框=資框.interpolate() #CSV檔案中若有缺漏，會使用內插法自動補值，不一定需要的功能
  資框.index=to_datetime(資框.index) #將索引欄資料轉換成pandas的時間格式，backtesting才有辦法排序
  test = Backtest(資框, SmaCross, cash=10000, commission=.002)  #指定回測程式為test，在Backtest函數中依序放入(資料來源、策略、現金、手續費)
  result=test.run()   #執行回測程式並存到result中
  rndrCode(result)  # 直接rndrCode文字結果
  test.plot(filename=f"./backtest_result/{stock}.html")     #將線圖網頁依照指定檔名保存
