from pandas import DataFrame, read_html
from stUtil import rndrCode
from bs4 import BeautifulSoup
from requests import get as rqstGET
from streamlit import multiselect, sidebar, columns as stCLMN, radio as stRadio, text_input, tabs as stTAB, data_editor, session_state

def 殖利率(dividend, price):
  yieldrate = round(dividend/price*100, 2) #殖利率 = 股利/股價 * 100%
  if yieldrate > 5: #殖利率>5%的股票  設定預算(殖利率>5%且股價<60的股票)寫法: if yieldrate > 5 and price < 60:
    return f"{stock} {yieldrate}% 股價:{price} 股利:{dividend}"

def web(url):
  source = rqstGET(url, headers={'Connection':'close'}) #連線到指定的網站
  soup = BeautifulSoup(source.content, 'lxml', from_encoding='utf-8') #讀取這個網頁的內容
  return soup #最終結果:回傳網頁內容

MENU, 表單=[], ['淨營運', '', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  #欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
  data = read_html('https://isin.twse.com.tw/isin/C_public.jsp?strMode=2', encoding='big5hkscs', header=0)[0]
  data = DataFrame(data['有價證券代號及名稱'])
  data = data['有價證券代號及名稱'].astype(str)
  for stock in data.iloc[1:964] :
      try:
          stockid = stock[:4]
          price_url = 'https://tw.stock.yahoo.com/quote/' + stockid #股價的網址
          dividend_url = 'https://tw.stock.yahoo.com/quote/' + stockid + '/dividend' #股利的網址
          span = web(price_url).find_all("span")
          for p in span:
              if p.text == '成交':
                  price = float(span[span.index(p) + 1].string) #股價

          span = web(dividend_url).find_all("span", class_="")
          dividend = float(span[28].string) #2021股利
          殖利率(dividend, price)
      except:
          continue
elif menu==MENU[0]: #淨營運
  pass
  #rndrCode("符合條件的股票:")
  try: data=session_state['股代碼']#=read_html('http://isin.twse.com.tw/isin/C_public.jsp?strMode=2', encoding='big5hkscs', header=0)[0]
  except: data=session_state['股代碼']=read_html('http://isin.twse.com.tw/isin/C_public.jsp?strMode=2', encoding='big5hkscs', header=0)[0]
  data = DataFrame(data["有價證券代號及名稱"])
  data = data["有價證券代號及名稱"].astype(str)
  for x in data.iloc[1:964] :   #不一定是964 因為每天都可能有股票會上市或下市
      try:
          stockid = x[:4] #股票代號
          balance_url = "https://tw.stock.yahoo.com/quote/" + stockid +"/balance-sheet" #資產負債表的網址
          share_url = "https://tw.stock.yahoo.com/quote/"+ stockid +"/profile" #股數的網址
          price_url = "https://tw.stock.yahoo.com/quote/"+ stockid #股價的網址
          balance = web(balance_url).find_all("span")[107:]
          for y in balance:
              if y.text == "流動資產":
                  a = balance.index(y) + 4 #流動資產資料的位置
                  asset = int(balance[a].string.replace(",", ""))*1000 #流動資產
              elif y.text == "總負債":
                  b = balance.index(y) + 4 #總負債資料的位置
                  liab = int(balance[b].string.replace(",", ""))*1000 #總負債
          div = web(share_url).find_all("div", class_="Py(8px) Pstart(12px) Bxz(bb)")
          share = int(div[16].string.replace(",", "")) #股數
          span = web(price_url).find_all("span")
          for z in span:
              if z.text == "成交":
                  p = span.index(z) + 1 #股價資料的位置
                  price = float(span[p].string) #股價
          #公式:股價<淨營運資本
          #淨營運資本 = (流動資產-總負債)/股數
          if(price < (asset-liab)/share):
              rndrCode(x)
      except:
          continue
