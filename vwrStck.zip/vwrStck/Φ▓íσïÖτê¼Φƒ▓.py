from requests import post as rqstPOST
from stUtil import rndrCode
from pandas import concat as pndsConcat, to_numeric, read_html
import numpy as np

def 財務報表(year, season, type='綜合損益彙總表'):
    if year >= 1000: year -= 1911
    if type == '綜合損益彙總表': url = 'https://mops.twse.com.tw/mops/web/ajax_t163sb04'
    elif type == '資產負債彙總表': url = 'https://mops.twse.com.tw/mops/web/ajax_t163sb05'
    elif type == '營益分析彙總表': url = 'https://mops.twse.com.tw/mops/web/ajax_t163sb06'
    else: rndrCode('type does not match')
    回應 = rqstPOST(url, {'encodeURIComponent':1, 'step':1, 'firstin':1, 'off':1, 'TYPEK':'sii', 'year':str(year), 'season':str(season), })
    回應.encoding = 'utf8'
    股資框 = read_html(回應.text, header=None)
    return pndsConcat(股資框[1:], axis=0, sort=False).set_index(['公司代號']).apply(lambda s: to_numeric(s, errors='ceorce'))
'''
from bs4 import BeautifulSoup
import urllib.request 
response = urllib.request.urlopen('http://php.net/') 
html = response.read()
soup = BeautifulSoup(html,"html.parser")
text = soup.get_text(strip=True)
print (text)

'''
