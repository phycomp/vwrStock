from yfinance import as yf Ticker
from streamlit import sidebar, multiselect, radio as stRadio, text_input
from pandas import DataFrame

sox = Ticker("^SOX") # 獲取費半指數歷史數據
sox_hist = sox.history(period="2y", interval="1d")

nasdaq = Ticker("^IXIC") # 獲取納斯達克指數
nasdaq_hist = nasdaq.history(period="2y", interval="1d")
from twstock import Stock

股碼=['2330']
MENU, 表單=[], ['連動', '', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  股=multiselect('股代碼', 股碼, default=股碼[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[2]: # 二、特征工程與數據對齊
  機器學習()
elif menu==MENU[1]: # 二、特征工程與數據對齊
  #1. 時間軸對齊處理  統一時區并合并數據集
  df_sox = sox_hist.reset_index()[['Date', 'Close']].rename(columns={'Close':'SOX'})
  df_nasdaq = nasdaq_hist.reset_index()[['Date', 'Close']].rename(columns={'Close':'NASDAQ'})
  merged = pd.merge_asof(
      df_tsmc.sort_values('date'),
      df_sox.sort_values('Date'),
      left_on='date', 
      right_on='Date',
      direction='backward'
  ).merge(df_nasdaq, on='Date', how='left') # 合并所有數據

  merged['SOX_chg'] = merged['SOX'].pct_change() # 計算隔夜美股漲跌幅作爲特征
  merged['NASDAQ_chg'] = merged['NASDAQ'].pct_change()
# 半導體行業相對強度 2. 關鍵衍生特征
  merged['SOX_vs_NASDAQ'] = merged['SOX'] / merged['NASDAQ']

  merged['rolling_corr'] = merged['close'].rolling(20).corr(merged['SOX']) # 台股與費半指數相關性 (滾動20日)

  # 美元匯率影響因子 (假設已獲取匯率數據USD/TWD)
  merged['export_impact'] = merged['USD/TWD'] * merged['close']  # 模藕出口企業價格影響
elif menu==MENU[0]: #連動
  pass
# 獲取台積電(2330)數據
  tsmc = twstock.Stock(股)
  tsmc_data = tsmc.fetch_from(2022, 1)  # 獲取2022年至今數據

# 轉換爲DataFrame
  資框台積電 = DataFrame({
      'date': [d.date for d in tsmc_data],
      'close': [d.close for d in tsmc_data],
      'volume': [d.capacity for d in tsmc_data]
  })
三、機器學習模型構建
1. 模型架構設計 (使用LSTM+宏觀因子)
四、交易策略整合框架
1. 動態權重分配策略
def dynamic_weight_allocation(pred_prob, risk_score):
    """
    根據預測置信度與市場風險調整倉位
    """
    base_weight = pred_prob[0] - pred_prob[2]  # 看漲概率 - 看跌概率
    risk_adjusted = base_weight * (1 - risk_score)  # risk_score∈[0,1], 越高越保守
    
    # 根據波動率調整
    volatility = merged['close'].pct_change().std() * 100  # 近期波動率%
    final_weight = risk_adjusted * (20 / volatility)  # 波動率20%時爲基準倉位
    
    return np.clip(final_weight, -1, 1)  # 限制在[-1,1]區間
2. 跨境套利監控模塊
def cross_market_arbitrage(sox, tsmc, fx_rate):
    """
    監控台美半導體股溢價空間
    """
    # 計算市盈率比值
    pe_ratio_sox = sox.get_info()['trailingPE']
    pe_ratio_tsmc = tsmc.get_info()['trailingPE']
    pe_spread = pe_ratio_tsmc / pe_ratio_sox
    
    # 匯率調整價差
    theoretical_spread = ...  # 需根據歷史回歸模型計算
    arbitrage_opp = (pe_spread - theoretical_spread) / theoretical_spread
    
    if arbitrage_opp > 0.15:
        return "做多SOX/做空TSMC"
    elif arbitrage_opp < -0.15:
        return "做空SOX/做多TSMC"
    else:
        return "無顯著套利機會"
五、實時預警系統
1. 多市場數據流整合
import websocket
import threading

def on_message(ws, message):
    data = json.loads(message)
    
    # 美股數據觸發台股預警
    if data['symbol'] == '^SOX':
        sox_price = data['price']
        last_tsmc_close = merged['close'].iloc[-1]
        
        # 計算隱含台股開盤價
        beta = 1.25  # 台積電對費半指數的貝塔值
        implied_open = last_tsmc_close * (1 + beta * (data['pct_change']))
        
        if abs(implied_open - last_tsmc_close) > 0.03:
            alert = f"費半指數波動預警! 台積電隱含開盤價: {implied_open:.2f} (+{(implied_open/last_tsmc_close-1):.2%})"
            send_telegram_alert(alert)

# 啓動美股數據監聽
ws = websocket.WebSocketApp("wss://alpaca.markets/stream", on_message=on_message)
threading.Thread(target=ws.run_forever).start()
2. 關鍵聯動指標儀表板
import plotly.graph_objects as go

fig = go.Figure()
fig.add_trace(go.Scatter(x=merged['date'], y=merged['close'], name='TSMC'))
fig.add_trace(go.Scatter(x=merged['Date'], y=merged['SOX'], name='SOX', yaxis='y2'))

fig.update_layout(
    title='台美半導體股聯動分析',
    yaxis=dict(title='TSMC Price (TWD)'),
    yaxis2=dict(title='SOX Index', overlaying='y', side='right'),
    hovermode="x unified"
)
fig.show()
六、風險控制特別設計
1. 聯動失效監測
def correlation_break_check(window=60, threshold=0.6):
    """
    監控台股與費半指數相關性是否異常
    """
    rolling_corr = merged['close'].rolling(window).corr(merged['SOX'])
    last_corr = rolling_corr.iloc[-1]
    
    if last_corr < threshold:
        return f"⚠️ 聯動性降至 {last_corr:.2f} (歷史均值 {rolling_corr.mean():.2f})"
    else:
        return "聯動性正常"

# 加入每日自動檢查
schedule.every().day.at("18:00").do(correlation_break_check)
2. 壓力情景模藕
def stress_test_scenarios():
    scenarios = {
        'SOX暴跌10%': {'SOX_chg': -0.10, 'VIX': 35},
        '美元急升3%': {'USD/TWD': 1.03 * current_fx},
        '雙重衝擊': {'SOX_chg': -0.08, 'USD/TWD': 1.02}
    }
    
    for name, params in scenarios.items():
        simulated_input = prepare_simulation_data(params)
        pred = model.predict(simulated_input)
        print(f"{name}情境預測結果: {np.argmax(pred)}")
關鍵注意事項與優化方向：
時區處理最佳實踐

# 統一轉換爲UTC+8時間戳
merged['timestamp'] = pd.to_datetime(merged['Date']).dt.tz_localize('UTC').dt.tz_convert('Asia/Taipei')
避免過度依賴歷史關聯

動態調整貝塔系數：
rolling_beta = merged['close'].rolling(90).cov(merged['SOX']) / merged['SOX'].rolling(90).var()
實時數據延遲補償

def adjust_for_delay(realtime_price, implied_change):
    # 使用卡爾曼濾波進行延遲補償
    kf = KalmanFilter(transition_matrices=[1],
                     observation_matrices=[1],
                     initial_state_mean=0,
                     process_noise=0.1,
                     observation_noise=0.5)
    state_means, _ = kf.filter(realtime_price)
    return state_means[-1] * implied_change
多模型委員會機制

class ModelEnsemble:
    def __init__(self):
        self.models = {
            'LSTM': load_lstm_model(),
            'Prophet': load_prophet_model(),
            'GARCH': load_garch_model()
        }
    
    def vote(self, current_data):
        predictions = []
        for name, model in self.models.items():
            pred = model.predict(current_data)
            predictions.append(pred)
        return np.mean(predictions, axis=0)
優化路線圖建議：

反饋優化

數據層

特征工程

模型層

策略整合

風險控制

實時系統

績效分析

通過整合跨境市場因子與機器學習模型，可顯著提升對台股趨勢（尤其是科技股）的預測能力。但需注意：

地緣政治風險：美中台關系等非量化因子需人工監控
產業周期差異：美國設計端 vs 台灣制造端的周期錯位
數據新鮮度：SEMI設備出貨數據等產業指標通常滞後1-2個月
建議搭配 台股ADR折溢價監控 與 外資買賣超數據 作為輔助驗證指標。
