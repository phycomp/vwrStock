def 損益表(year, season, type='綜合損益彙總表'):
    if year >= 1000: year -= 1911
    if type == '綜合損益彙總表':
        url = 'https://mops.twse.com.tw/mops/web/ajax_t163sb04'
    elif type == '資產負債彙總表':
        url = 'https://mops.twse.com.tw/mops/web/ajax_t163sb05'
    elif type == '營益分析彙總表':
        url = 'https://mops.twse.com.tw/mops/web/ajax_t163sb06'
    else:
        print('type does not match')
    r = requests.post(url, {
        'encodeURIComponent':1,
        'step':1,
        'firstin':1,
        'off':1,
        'TYPEK':'sii',
        'year':str(year),
        'season':str(season),
    })
    r.encoding = 'utf8'
    dfs = pd.read_html(r.text, header=None)
    if (type=='營益分析彙總表'):
        df=dfs[0].iloc[1:,:].copy()
        df.columns=dfs[0].iloc[0,:]
        df.index=df['公司代號']
        df.drop(columns=['公司代號'],inplace=True)
        return df
    else:
        return pd.concat(dfs[1:], axis=0, sort=False).set_index(['公司代號']).sort_index()

