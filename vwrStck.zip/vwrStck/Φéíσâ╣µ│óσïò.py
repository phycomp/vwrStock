#!/usr/bin/env python
# coding: utf-8

接著，為了方便重複使用爬蟲程式碼，如先前所述，我們確定了網址的命名規則。因此，下面我們展示設計完成的函數直接進行解說：

函數的傳入參數 symbol 為字串，例如 ”006208” 等。
在傳入參數後，我們把代碼放入 URL 中。這裡使用的是 Python 3.6 之後新增的字串格式寫法：雙引號左側放一個 f，中間的變數用大括號 {} 包起來。
接著我們用 requests 套件的 get 方法把 URL 的訪問內容拿回來，如函數內第二行程式碼。
再來，用 BeautifulSoup 解析網頁內容，並且搜尋第一個 class_ 值為 “datalist” 的table（知道要這麼解析，是因為我們已經事先把訪問內容列印出來，知道網頁結構是如此）
進入 for 迴圈即是典型的表格解析方法，先以 te 區分每一列，再以 td 區分每一個儲存格。在這個範例中，我們僅需要用到第 1, 2, 6 行，因此在儲存每一列資料到 list_rows 時，我們刻意只取 [1, 2, 6]。
最後，我們把解析完的資料製作成 pd.DataFrame，另外再加入一個 column 來註記這是哪個 ETF 的配息歷史資料，就大功告成啦！
為什麼要另外製作 ETF 代碼的 colomn 呢？試想一下，如果我們現在有 200 個 ETF 的配息歷史資料需要爬取，搭配 ETF 代碼的 colomn 後，我們就能夠把所有資料整併進一個 pd.DataFrame ，方便管理和後續取用。

以 0050 為例，我們試著運行看看這個爬蟲程式：


# In[3]:


from twstock import *


# In[4]:


pd.set_option('display.max_rows', 5000)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)
plt.rcParams['font.sans-serif'] = ['Microsoft JhengHei'] 
plt.rcParams['axes.unicode_minus'] = False


# In[18]:


p0 = TwPrice('20200102', '上市')[['股價日期', '證券代號', '證券名稱', '收盤價']]


# In[20]:


p0.head()


# In[19]:


p1 = TwPrice('20200324', '上市')[['股價日期', '證券代號', '證券名稱', '收盤價']]


# In[21]:


p1.head()


# In[30]:


px = pd.merge(p0,p1,on=['證券代號', '證券名稱'],how='left')
px = px[['證券代號', '證券名稱', '股價日期_x', '收盤價_x', '股價日期_y', '收盤價_y']]
px['差價'] = px['收盤價_y'] - px['收盤價_x']
px['價格波動(%)'] = round(100 * px['差價'] / px['收盤價_x'], 2)


# In[31]:


px.head()


# In[34]:


px[~px['證券名稱'].str.contains('|'.join(('購','售')))].sort_values(by='價格波動(%)').head(100)


# In[ ]:




