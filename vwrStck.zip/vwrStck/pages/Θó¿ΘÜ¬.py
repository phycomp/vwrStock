from streamlit import sidebar, multiselect, radio as stRadio, text_input
from 風險控管 import 動態止損

MENU, 表單=[], ['風險控管', '', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[2]: #
  pass
elif menu==MENU[1]: #
  pass
  account_balance = 1000000  # 假設帳戶餘額 100 萬
  shares = position_sizing(account_balance, stop_loss_distance=entry_price - stop_loss)
  rndrCode(f"可買入股數: {shares}")
elif menu==MENU[0]: #風險控管
  pass
  entry_price = 600  # 假設買入台積電 600 元
  止損, 停利=動態止損('2330', entry_price)
  rndrCode(f"止損位: {止損:.2f}, 止盈位: {停利:.2f}")

