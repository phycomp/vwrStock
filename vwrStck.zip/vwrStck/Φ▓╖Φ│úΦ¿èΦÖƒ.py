from twstock import Stock
from twstock.analytics import BestFourPoint
from rndrCode import rndrCode

def 買賣(所有股):
    結果 = {}
    for 股碼 in 所有股:
      try:
        股 = Stock(股碼)
        b = BestFourPoint(股)
        bfp = b.best_four_point()
        buy_or_sell = "hmmmm, don't touch"
        if bfp and bfp[0] is True: buy_or_sell = "進場->" + bfp[1]
        elif bfp and bfp[0] is False: buy_or_sell = "出售->" + bfp[1]
        結果[str(股.sid)] = {'訊號': buy_or_sell, '價格': 股.price[-5:]}
      except: 結果[股碼]=None
    return 結果     #該股, 股#render_template('stocker.html', stock_id=stock_list, stock=st, name=stock_name)

def 股價(stock_id):
    s = Stock(stock_id)
    ret = []
    today = datetime.today()
    stock_closing = 1 if today < today.replace(hour=13, minute=30, second=0) else 0
    for index, i in enumerate(s.price[-5:]):
        date = today - timedelta(days=(4 - index + stock_closing))
        結果={'date': date.strftime('%Y-%m-%d'), 'price':i}
        ret.append(結果)
    return jsonify(ret)
