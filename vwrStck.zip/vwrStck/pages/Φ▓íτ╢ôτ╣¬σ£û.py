from streamlit import sidebar, multiselect, radio as stRadio, text_input
from pandas import read_csv
from mplfinance import plot as mpfPlot
from matplotlib.pyplot import subplots, subplot, figure
from streamlit import pyplot

MENU, 表單=[], ['財經繪圖', '其它', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  #欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
elif menu==MENU[0]: #財經繪圖
  單日 = read_csv('/home/josh/Downloads/SP500_NOV2019_Hist.csv',index_col=0,parse_dates=True)
  #fig, ax = subplots()
  #ax.scatter([1, 2, 3], [1, 2, 3])
  #pyplot(fig) other plotting actions...

  fig = figure(figsize = (3,3))

  單日.index.name = 'Date'
  單日.shape
  單日.head(3)
  單日.tail(3)
  單圖=mpfPlot(單日)
  subplot(2, 2, 1);
  pyplot(單圖)

  subplot(2, 2, 2);
  單圖=mpfPlot(單日, type='candle')
  pyplot(單圖)

  subplot(2, 2, 3);
  單圖=mpfPlot(單日, type='line')
  pyplot(單圖)

  subplot(2, 2, 4);
  單圖=mpfPlot(單日, type='ohlc', mav=4)
  pyplot(單圖)
  #單圖=mpfPlot(單日, mav=(3,6,9), type='candle')
  #pyplot(單圖)
  #單圖=mpfPlot(單日, type='candle', mav=(3,6,9), volume=True)
  #pyplot(單圖)

  年趨勢 = read_csv('/home/josh/Downloads/SPY_20110701_20120630_Bollinger.csv',index_col=0,parse_dates=True)
  年趨勢.index.name = 'Date'
  mpfPlot(年趨勢,type='renko')
  mpfPlot(年趨勢,type='pnf')
