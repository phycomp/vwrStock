from streamlit import sidebar, session_state, radio as stRadio, columns as stCLMN, text_area, text_input, multiselect
from streamlit import toggle as stToggle, markdown as stMarkdown #slider, dataframe, code as stCode, cache as stCache, 
from pandas import read_html
from stUtil import rndrCode
from requests import get as rqstGET
MENU, 表單=[], ['前500大', '美個股', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
美股欄位=['Company', 'Symbol', 'Weight', 'Price', 'Chg', '% Chg']
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  美欄=multiselect('美欄', 美股欄位)#, horizontal=True, index=0)
  srch=text_input('搜尋', 'Microsoft')
if menu==len(表單):
  pass
elif menu==MENU[1]:
  #美個股
  pass
elif menu==MENU[0]:
  #前500大
  url='https://www.slickcharts.com/sp500'
  headers={"User-Agent":'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36'}
  request=rqstGET(url, headers=headers)
  資框=read_html(request.text)[0]
  rndrCode(資框.columns)
  if 美欄 and srch:
    資框[資框[美欄[0]].str.contains(srch)]
    rndrCode(資框.columns)
    stk清單 = 資框.Symbol # 欄位『Symbol』就是股票代碼
    stk清單 = 資框.Symbol.apply(lambda x: x.replace('.', '-')) # 用 replace 將符號進行替換
    stk清單
