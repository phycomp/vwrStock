from yfinance import pdr_override
from datetime import datetime
from streamlit import sidebar, multiselect, radio as stRadio, text_input
from backtesting import Backtest, Strategy  #引入回測和交易策略功能
from backtesting.lib import crossover   #從lib子模組引入判斷均線交會功能
from backtesting.test import SMA    #從test子模組引入繪製均線功能
from pandas import Dataframe, to_datetime  #引入pandas讀取股價歷史資料CSV檔
#from pandas_datareader import data
from 策略交易 import SmaCross
from backtesting import Backtest, Strategy #引入回測和交易策略功能
from backtesting.lib import crossover #引入判斷均線交會功能
from backtesting.test import SMA #引入繪製均線功能

MENU, 表單=[], ['交易', '', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
  個股 = "TSLA" #設定要測試的股票標的名稱
  資框 = read_csv(f"data/{個股}.csv", index_col=0) #pandas讀取資料，並將第1欄作為索引欄
  資框 = 資框.interpolate() #CSV檔案中若有缺漏，會使用內插法自動補值，不一定需要的功能
  資框.index = pd.to_datetime(資框.index) #將索引欄資料轉換成pandas的時間格式，backtesting才有辦法排序
  test = Backtest(資框, SmaCross, cash=10000, commission=.002)
  # 指定回測程式為test，在Backtest函數中依序放入(資料來源、策略、現金、手續費)
  result = test.run()
  #執行回測程式並存到result中
  print(result) # 直接print文字結果
  test.plot(filename=f"./backtest_result/{個股}.html") #將線圖網頁依照指定檔名保存
elif menu==MENU[1]: #
  pass
  個股 = "TSLA" #設定要測試的股票標的名稱
  資框 = pd.read_csv(f"./data/{個股}.csv", index_col=0) #pandas讀取資料，並將第1欄作為索引欄
  資框 = 資框.interpolate() #CSV檔案中若有缺漏，會使用內插法自動補值，不一定需要的功能
  資框.index = pd.to_datetime(資框.index) #將索引欄資料轉換成pandas的時間格式，backtesting才有辦法排序
  test = Backtest(資框, SmaCross, cash=10000, commission=.002) # 指定回測程式為test，在Backtest函數中依序放入(資料來源、策略、現金、手續費)
  result = test.run()
elif menu==MENU[0]: #交易
  pass
  #pdr_override() #以pandasreader常用的格式覆寫
  個股 = 'TSLA'  #股票代號變數
  start_date = datetime(2010, 1, 1)
  end_date = datetime(2020, 6, 30) #設定資料起訖日期
  資框 = data.get_data_yahoo([個股], start_date, end_date) #將資料放到Dataframe裡面
  filename = f'./data/{target_stock}.csv' #以股票名稱命名檔案，放在data資料夾下面
  資框.to_csv(filename) #將資框轉成CSV保存
