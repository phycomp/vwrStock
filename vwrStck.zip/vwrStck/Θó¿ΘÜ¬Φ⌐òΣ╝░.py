初學者的Python金融分析日記 EP3 -股票收益率與風險評估 18 6 月, 2019 PyInvest
股票收盤價日線資料探索
我們今天的筆記本討論一下怎麼用pandas與matplotlib對資料做基本的探索，然後我們嘗試用簡單的方法估計持有股票的風險程度。
對於一個投資者來說，了解股票投資的風險度應該是很重要的，這就是，我們想要估計我們股票的價格的波動程度，但是如果昨天價格的統計性質與今天價格的統計性質有很大的不一樣，我們就沒有辦法合理評估今天價格的波動程度，同時，如果前一期與後一期的股價之間如果有很強的關聯性，讓我們的波動估計可能也需要做調整，因此，檢驗我們的資料是否可以用一個獨立且相同分配的關係來描述也是一個重要課題。 首先，我們先載入套件庫以及相關資料。
# 載入套件庫並讀入資料
import pandas as pd
import matplotlib.pyplot as plt
import sqlite3
import numpy as np
db = sqlite3.connect('TWStock_2')
#這邊我們挑選一些台灣的代表性股票
stocks_dict = {}
#台積電2330
stocks_dict.update({'tsmc':pd.read_sql(con=db,sql='SELECT * FROM "2330"')})
#台塑化6505
stocks_dict.update({'fpc':pd.read_sql(con=db,sql='SELECT * FROM "6505"')})
#鴻海2317
stocks_dict.update({'foxconn':pd.read_sql(con=db,sql='SELECT * FROM "2317"')})
#中華電2412
stocks_dict.update({'cht':pd.read_sql(con=db,sql='SELECT * FROM "2412"')})
#台塑1301
stocks_dict.update({'fpg':pd.read_sql(con=db,sql='SELECT * FROM "1301"')})
#台化1326
stocks_dict.update({'fcfc':pd.read_sql(con=db,sql='SELECT * FROM "1326"')})
#國泰金2882
stocks_dict.update({'cfh':pd.read_sql(con=db,sql='SELECT * FROM "2882"')})
#南亞1303
stocks_dict.update({'ny':pd.read_sql(con=db,sql='SELECT * FROM "1303"')})
#富邦金2881
stocks_dict.update({'fubon':pd.read_sql(con=db,sql='SELECT * FROM "2881"')})
#大立光3008
stocks_dict.update({'largan':pd.read_sql(con=db,sql='SELECT * FROM "3008"')})
這邊我們連接到我們上一次建立的資料庫並將選擇載入的表單存為字典的格式。
繪製基本股價走勢圖
我們在這邊先繪製這幾隻股票的收盤價的走勢圖
'''
在畫圖之前，
我們先整理我們的資料，將每個股票整理成股票名稱與收盤價的表格形式，
其中，因為收盤價被存為字串形式，我們也必須轉為數值形式做進一個的運算
'''
for key in stocks_dict.keys():
    df = stocks_dict[key]
    df.index = df['Date']
    df.index = pd.to_datetime(df.index)
    df = df[['證券名稱','收盤價']]
    df['收盤價'] = pd.to_numeric(df['收盤價'].apply(lambda x:x.replace(',','')),errors='coerce')
    df.columns = ['stock_code','close']
    stocks_dict[key] = df
fig,ax = plt.subplots(3,2,figsize=(10,10))
plt.subplots_adjust(hspace=0.8)
stocks_dict['largan']['2018-01-01':].plot(ax=ax[0,0])
ax[0,0].set_title('Largan')
stocks_dict['tsmc']['2018-01-01':].plot(ax=ax[0,1])
ax[0,1].set_title('TSMC')
stocks_dict['fubon']['2018-01-01':].plot(ax=ax[1,0])
ax[1,0].set_title('Fubon')
stocks_dict['cfh']['2018-01-01':].plot(ax=ax[1,1])
ax[1,1].set_title('CFH')
stocks_dict['fpg']['2018-01-01':].plot(ax=ax[2,0])
ax[2,0].set_title('FPG')
stocks_dict['fpc']['2018-01-01':].plot(ax=ax[2,1])
ax[2,1].set_title('FPC')
fig.suptitle('Stock Price via time')
plt.show()
我們先對每張表單進行清理，然後畫成一個3乘2的圖群。
圖像判斷法
如果我們要用最簡單的方式來估計我們持有股票的風險度的話，應該就是去估計股票的波動程度了，而我們可以選擇用標準差這個最常見的方式來測量波動程度。但是問題是，如果昨天的股票的統計性質與明天的股票的統計性質相差很大的話，我們就很難相信我們用過去股價估計出來的波動程度可以有效的衡量明天股價的波動程度，也就是說，我們希望我們前後天的股價是獨立且有相似的分配的，我們這邊可以用很簡單的圖像方式來呈現前後天股價的關係。
#用TSMC做例子
df = stocks_dict['tsmc'].copy()
df_p = df['2018-01-01':].iloc[:-1,:]
df_a = df['2018-01-01':].iloc[1:,:]
plt.scatter(np.array(df_p['close']),np.array(df_a['close']))
plt.show()
plt.hist([np.array(df['2018-01-01':'2018-09-01']['close']),np.array(df['2018-09-01':]['close'])])
可以發現，前一期的股價與一期的股價並非沒有關係，可以看到兩者之間有正向關係。讓我們想想辦法，我們不直接計算股價，而是計算兩個不同的報酬率
df_lrp = df.iloc[:-1,:]
df_lra = df.iloc[1:,:]
plt.scatter(np.array(df_lrp['linear return rate']),np.array(df_lra['linear return rate']))
plt.show()
可以發現，當我們做報酬率的轉換後，其前後期關係更接近於獨立關係，我們可以更有信心估計報酬率波動程度。而當前後期股價接近時，根據泰勒展開式，我們支到線性報酬率與連續報酬率的值近似。所以我們可以用以下的統計模型
則我們可以利用一些常見的方法(e.g. MLE)去估計參數，進而得到我們對於報酬的分配估計，而在這種情況下我們就可以評估我們的風險水準了！
