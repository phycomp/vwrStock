from requests import post as rqstPOST
from stUtil import rndrCode
from io import StringIO
from pandas import read_csv, to_numeric
from streamlit import sidebar, multiselect, radio as stRadio, text_input
趣股={'2330':'台積電', '1215':'群峰'}
台股=list(趣股.keys())
MENU, 表單=[], ['本益比', '分析', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
股欄=['證券代號', '證券名稱', '成交股數', '成交筆數', '成交金額', '開盤價', '最高價', '最低價', '收盤價', '漲跌(+/-)', '漲跌價差', '最後揭示買價', '最後揭示買量', '最後揭示賣價', '最後揭示賣量', '本益比', 'Unnamed: 16']
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  股=stRadio('股市欄位', 台股, horizontal=True, index=0)
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[2]: #
  pass
elif menu==MENU[1]: #
  pass
  from utilStck import 繪均線
  if 股:
    繪均線(股)
elif menu==MENU[0]: #本益比
  pass
  datestr = '20220819' #查詢日期
  回 = rqstPOST('http://www.twse.com.tw/exchangeReport/MI_INDEX?response=csv&date=' + datestr + '&type=ALL')
  資料=StringIO("\n".join([值.translate({ord(c): None for c in ' '}) for 值 in 回.text.split('\n') if len(值.split('",')) == 17 and 值[0] != '=']))
  資框 = read_csv(資料, header=0 , thousands=",")
  rndrCode([資框.columns])  #
  資框[欄股]
  #條件篩選，5<本益比<15 且 收盤價<300 且 (成交股數/1000）>10000張
  資框.loc[(to_numeric(資框['本益比'], errors='coerce') < 15) & (to_numeric(資框['本益比'], errors='coerce') > 5) & (to_numeric(資框['收盤價'], errors='coerce') < 300) & (to_numeric(資框['成交股數'], errors='coerce')/1000 > 10000)]

