from trendspy import Trends
from stUtil import rndrCode
from streamlit import sidebar, session_state, radio as stRadio, columns as stCLMN, text_area, text_input, multiselect
from streamlit import toggle as stToggle, markdown as stMarkdown #slider, dataframe, code as stCode, cache as stCache, 

MENU, 表單=[], ['分析趨勢', '美股趨勢', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
關鍵字=['NVDA', 'AAPL', 'MSFT']
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  關=multiselect('關鍵字趨勢', 關鍵字, default=關鍵字[0])
  srch=text_input('搜尋', '')
if menu==len(表單):
  pass
elif menu==MENU[1]:
  pass
elif menu==MENU[0]:
  #分析趨勢
  from 趨析 import 趨析
  if 關:
    趨勢 = Trends()
    趨析(趨勢, 關)
