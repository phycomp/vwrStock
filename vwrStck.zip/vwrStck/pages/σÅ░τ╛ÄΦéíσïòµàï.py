from twstock import Stock, realtime as twsRealtime
from pandas import DataFrame
from stUtil import rndrCode
from streamlit import sidebar, multiselect, radio as stRadio, text_input
from stckUtil import 監控股價, rsi指標

MENU, 表單=[], ['台股', '美股', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
趣股=['0050', '2330', '2317', '1301', '1326', '2412', '3008', '1303', '2308', '2454', '2881', '8299']   #台積電->'2330'
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  股碼=stRadio('股', 趣股, horizontal=True, index=0)    #, default=趣股[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
elif menu==MENU[0]: #台股
  pass

  if 股碼:
    股 = Stock(股碼) #台積電 獲取即時股票資料（台股代號，例如台積電: 2330）

  即時 = twsRealtime.get(股碼) # 獲取當日即時數據（需在台股交易時段運行）

  if 即時['success']:
    #rndrCode(即時['realtime'])
    rndrCode(f"即時股價: {即時['realtime']['latest_trade_price']}")
    rndrCode(f"累積成交量: {即時['realtime']['accumulate_trade_volume']}")
  else:
      rndrCode("獲取數據失敗")

  個股 = Stock('2330')
  股價 = 個股.price[-30:]  # 最近30天收盤價
  # 計算5日和20日移動平均線
  資框 = DataFrame({'close': 股價})
  資框['MA5'] = 資框['close'].rolling(window=5).mean()
  資框['MA20'] = 資框['close'].rolling(window=20).mean()

  rndrCode(資框.tail())
  資框['RSI'] = rsi指標(資框['close'], 14)
  rndrCode(資框.tail())
  #4. 簡單交易策略範例
  #策略1：移動平均線交叉  判斷黃金交叉（買入信號）
  五日均價 = 資框['MA5'].iloc[-1]
  廿日均價 = 資框['MA20'].iloc[-1]
  前五均價 = 資框['MA5'].iloc[-2]
  前廿均價 = 資框['MA20'].iloc[-2]

  if 前五均價 < 前廿均價 and 五日均價 > 廿日均價:
      rndrCode("黃金交叉出現，建議買入")
  elif 前五均價 > 前廿均價 and 五日均價 < 廿日均價:
      rndrCode("死亡交叉出現，建議賣出")
  else:
      rndrCode("無交叉信號")
  latest_rsi = 資框['RSI'].iloc[-1] #策略2：RSI 超買超賣
  if latest_rsi > 70:
      rndrCode("RSI 超買，建議減倉或賣出")
  elif latest_rsi < 30:
      rndrCode("RSI 超賣，可能有反彈機會")
  else:
      rndrCode("RSI 在正常範圍")

  監控股價(股碼) # 監控台積電（2330）
