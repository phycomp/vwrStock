#!/usr/bin/env python
# coding: utf-8
from mediapipe import solutions
from mediapipe.framework.formats import landmark_pb2
import numpy as np
from numpy import repeat npRepeat, copy as npCopy, newaxis as npNewaxis
from streamlit import sidebar, multiselect, radio as stRadio, text_input

# ##### Copyright 2023 The MediaPipe Authors. All Rights Reserved.

# In[ ]:


MENU, 表單=[], ['繪製', '', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
elif menu==MENU[0]: #繪製
  pass
#@title Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


# # Pose Landmarks Detection with MediaPipe Tasks
# 
# This notebook shows you how to use MediaPipe Tasks Python API to detect pose landmarks from images.

# ## Preparation
# 
# Let's start with installing MediaPipe.
# 

# In[ ]:


get_ipython().system('pip install -q mediapipe')


# Then download an off-the-shelf model bundle. Check out the [MediaPipe documentation](https://developers.google.com/mediapipe/solutions/vision/pose_landmarker#models) for more information about this model bundle.

# In[ ]:


get_ipython().system('wget -O pose_landmarker.task -q https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_heavy/float16/1/pose_landmarker_heavy.task')


# ## Visualization utilities

# In[ ]:


#@markdown To better demonstrate the Pose Landmarker API, we have created a set of visualization tools that will be used in this colab. These will draw the landmarks on a detect person, as well as the expected connections between those markers.



def 繪製骨架(rgb_image, 偵測):
  pose_landmarks_list = 偵測.pose_landmarks
  標注 = npCopy(rgb_image)

  # Loop through the detected poses to visualize.
  for idx in range(len(pose_landmarks_list)):
    pose_landmarks = pose_landmarks_list[idx]

    # Draw the pose landmarks.
    pose_landmarks_proto = landmark_pb2.NormalizedLandmarkList()
    pose_landmarks_proto.landmark.extend([
      landmark_pb2.NormalizedLandmark(x=landmark.x, y=landmark.y, z=landmark.z) for landmark in pose_landmarks
    ])
    solutions.drawing_utils.draw_landmarks(標注, pose_landmarks_proto, solutions.pose.POSE_CONNECTIONS, solutions.drawing_styles.get_default_pose_landmarks_style())
  return 標注

# ## Download test image
# 
# To demonstrate the Pose Landmarker API, you can download a sample image using the follow code. The image is from [Pixabay](https://pixabay.com/photos/girl-woman-fitness-beautiful-smile-4051811/).

# In[ ]:


get_ipython().system('wget -q -O image.jpg https://cdn.pixabay.com/photo/2019/03/12/20/39/girl-4051811_960_720.jpg')

import cv2
from google.colab.patches import cv2_imshow

img = cv2.imread("image.jpg")
cv2_imshow(img)


# Optionally, you can upload your own image. If you want to do so, uncomment and run the cell below.

# In[ ]:


# from google.colab import files
# uploaded = files.upload()

# for filename in uploaded:
#   content = uploaded[filename]
#   with open(filename, 'wb') as f:
#     f.write(content)

# if len(uploaded.keys()):
#   IMAGE_FILE = next(iter(uploaded))
#   print('Uploaded file:', IMAGE_FILE)


# ## Running inference and visualizing the results
# 
# The final step is to run pose landmark detection on your selected image. This involves creating your PoseLandmarker object, loading your image, running detection, and finally, the optional step of displaying the image with visualizations.
# 
# Check out the [MediaPipe documentation](https://developers.google.com/mediapipe/solutions/vision/pose_landmarker/python) to learn more about configuration options that this solution supports.
# 

# In[ ]:


# STEP 1: Import the necessary modules.
from mediapipe import Image
#from mediapipe.tasks import python
from mediapipe.tasks.python import vision, BaseOptions
from mediapipe.tasks.python.vision import PoseLandmarkerOptions, PoseLandmarker

# STEP 2: Create an PoseLandmarker object.
base_options = BaseOptions(model_asset_path='pose_landmarker.task')
options = PoseLandmarkerOptions(base_options=base_options, output_segmentation_masks=True)
detector = PoseLandmarker.create_from_options(options)

# STEP 3: Load the input image.
image = Image.create_from_file("image.jpg")

# STEP 4: Detect pose landmarks from the input image.
偵測 = detector.detect(image)

# STEP 5: Process the detection result. In this case, visualize it.
標注 = 繪製骨架(image.numpy_view(), 偵測)
cv2_imshow(cv2.cvtColor(標注, cv2.COLOR_RGB2BGR))


# Visualize the pose segmentation mask.

# In[ ]:


segmentation_mask = 偵測.segmentation_masks[0].numpy_view()
visualized_mask = npRepeat(segmentation_mask[:, :, npNewaxis], 3, axis=2) * 255
cv2_imshow(visualized_mask)

