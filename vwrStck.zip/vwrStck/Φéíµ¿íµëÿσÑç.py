import torch
import numpy as np
import pandas as pd DataFrame
from sklearn.preprocessing import StandardScaler
from torch.utils.data import Dataset, DataLoader
class StockDataset(Dataset):
  def __init__(self, stock_code, sox_data, fx_data, seq_length=30):
    # 獲取台股數據
    stock = twstock.Stock(stock_code)
    tsmc_data = stock.fetch_from(2020, 1)
    # 構建DataFrame
    self.df = DataFrame({
        'date': [d.date for d in tsmc_data],
        'close': [d.close for d in tsmc_data],
        'volume': [d.capacity for d in tsmc_data]
    })
    # 合并外部數據（假設已對齊時間戳）
    self.df = self.df.merge(sox_data, on='date', how='left')
    self.df = self.df.merge(fx_data, on='date', how='left')
    # 特征工程
    self.df['sox_pct'] = self.df['sox_close'].pct_change()
    self.df['fx_impact'] = self.df['usd_twd'] * self.df['close']
    # 標準化
    self.scaler = StandardScaler()
    features = ['close', 'volume', 'sox_pct', 'fx_impact']
    self.df[features] = self.scaler.fit_transform(self.df[features])
    self.seq_length = seq_length # 序列切割
    self.data = self._create_sequences()
  def _create_sequences(self):
    sequences = []
    for i in range(len(self.df) - self.seq_length - 1):
      seq = self.df.iloc[i:i+self.seq_length][['close', 'volume', 'sox_pct', 'fx_impact']].values
      label = self.df.iloc[i+self.seq_length]['close']
      sequences.append((seq, label))
    return sequences
  def __len__(self): return len(self.data)
  def __getitem__(self, idx):
    seq, label = self.data[idx]
    return torch.FloatTensor(seq), torch.FloatTensor([label])
