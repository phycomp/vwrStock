#黃金交叉 短期均線向上穿越長期均線 買進
#死亡交叉 短期均線向下穿越長期均線 賣出

from streamlit import plotly_chart
from twstock import Stock
from pandas import DataFrame
from plotly.graph_objects import Scatter, Figure
from streamlit import sidebar, multiselect, radio as stRadio, text_input

MENU, 表單=[], ['均線', '均價', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
趣股={'2330':'台積電', '1215':'群峰'}
股欄=[股 for 股 in 趣股.keys()]
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
elif menu==MENU[0]: #均線
  for 股碼 in 趣股:
    個股 = Stock(股碼)
    date = 個股.date #收盤價
    price = 個股.price
    data = DataFrame({'日期':date, '收盤價':price})
    五日 = date[4:] #5MA
    五日均價 = 個股.moving_average(price, 5)
    五均價 = DataFrame({'日期':五日, '5日平均價格':五日均價})

    十日 = date[9:] #10MA
    十日均價 = 個股.moving_average(price, 10)
    十均價 = DataFrame({'日期':十日, '10日平均價格':十日均價})

    廿日 = date[19:] #20MA
    廿日均價 = 個股.moving_average(price, 20)
    廿均價 = DataFrame({'日期':廿日, '20日平均價格':廿日均價})

    result = Figure()
    result.add_trace(Scatter( x=data['日期'], y=data['收盤價'], name='收盤價')) #收盤價的圖
    result.add_trace(Scatter( x=五均價['日期'], y=五均價['5日平均價格'], name='5日均價線')) #5MA的圖
    result.add_trace(Scatter( x=十均價['日期'], y=十均價['10日平均價格'], name='10日均價線')) #10MA的圖

    result.add_trace(Scatter( x=廿均價['日期'], y=廿均價['20日平均價格'], name='20日均價線')) #20MA的圖
    #result.update_layout(title_text=f"{趣股.get(股碼)}", title_x=0.5)
    result.update_layout(title_text=f"{趣股.get(股碼)}",
      hovermode='x unified', #滑鼠停在上面會有資訊卡
      xaxis=dict(domain=[.27, 1]), #調x軸座標的間距
      yaxis=dict(title='收盤價'), #收盤價 的 y軸座標
      yaxis2=dict( title='成交量', anchor='free', overlaying='y', position=0.1899),     #成交量 的 y軸座標
      yaxis3=dict( title='MA均量線', anchor='free', overlaying='y', position=0.098),    #5MA 的 y軸座標
      yaxis4=dict( overlaying='y', visible=False), #不顯示這個y軸座標 因為5MA、10MA、20MA單位一樣 所以只要顯示其中一個就好了 10MA 的 y軸座標

      yaxis5=dict( overlaying='y', visible=False) #20MA 的 y軸座標
  )
    plotly_chart(result)
