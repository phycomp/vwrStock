from yfinance import Ticker
from stUtil import rndrCode
from pandas import DataFrame
from matplotlib.pyplot import figure, plot, title, xlabel, ylabel, legend, grid
from streamlit import sidebar, multiselect, radio as stRadio, text_input, plotly_chart


MENU, 表單=[], ['美股', '分析', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  #欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
elif menu==MENU[0]: #美股
  symbol, 開始, 結束 ='AAPL', '2023-01-01', '2023-12-31'
  股 = Ticker(symbol)
  股資 = 股.history(start=開始, end=結束)
  股資['廿日均價'] = 股資['Close'].rolling(window=20).mean()
  股資['日價'] = 股資['Close'].pct_change() * 100
  rndrCode("Data with Moving Average and Daily Returns:")
  股頭=股資[['Close', '廿日均價', '日價']].head()
  股頭
  圖=figure(figsize=(12, 6))
  plot(股資['Close'], label='Close Price', color='blue')
  plot(股資['廿日均價'], label='20-Day Moving Average', color='orange')
  title(f'{symbol} Closing Price and 20-Day Moving Average')
  xlabel('Date')
  ylabel('Price')
  legend()
  plotly_chart(圖)
  #grid(True)
  #show()
