from numpy import array as npArray, reshape as npReshape
from keras.models import Sequential

def 訓模(train_x, train_y, test_x, test_y):
    model.fit(train_x, train_y, batch_size = 100, epochs = 300, validation_split = 0.1)
    predict = model.predict(test_x)
    predict = npReshape(predict, (predict.size, ))
    return predict

def 建模():
    model = Sequential()
    model.add(SimpleRNN(input_shape = (10, 3), units = 256, unroll = False))
    model.add(Dense(units = 1))
    model.compile(loss = "mse", optimizer = "adam", metrics = ["accuracy"])
    return model

def 載料(延展, 展延, feature_data, label_data, length, split):
    feature_all = npArray(feature_data).astype(float)
    feature_all = 延展.fit_transform(feature_all)
    label_all = npArray(label_data).astype(float)
    label_all = 展延.fit_transform(label_all)

    feature = []
    label = []
    for i in range(len(feature_all) - length):
        feature.append(feature_all[i: i + length])
        label.append(label_all[i + length])

    x = npArray(feature).astype("float64")
    y = npArray(label).astype("float64")

    split_boundary = int(x.shape[0] * split)
    train_x = x[: split_boundary]
    test_x = x[split_boundary: ]

    train_y = y[: split_boundary]
    test_y = y[split_boundary: ]

    return train_x, train_y, test_x, test_y
