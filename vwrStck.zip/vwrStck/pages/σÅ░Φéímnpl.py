import csv
from twstock import Stock
from sklearn.preprocessing import MinMaxScaler
#from twstock.codes import fetch
from pandas import read_csv, DataFrame
import os
from streamlit import sidebar, multiselect, radio as stRadio, text_input
from 台股util import 建模, 訓模, 載料
from numpy import array as npArray

MENU, 表單=[], ['fetch', '', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  #欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
elif menu==MENU[0]: #fetch
  #filepath = "stock2021.csv"
  data = []
  for i in range(1, 3):    # note1
      股 = Stock("1301")    # note2
      股清單 = 股.fetch(2021, i)
  股清單

  for stock in 股清單:
      strdate = stock.date.strftime("%Y-%m-%d")
      資 = [strdate, stock.capacity, stock.turnover, stock.open, stock.high, stock.low, stock.close, stock.change, stock.transaction]
      data.append(資)

  outputfile = open("stock2021.csv", "w", newline = "", encoding = "big5")    # note3 filepath
  outputwriter = csv.writer(outputfile)
  單='''日期,容量,折返,開盤價,最高價,最低價,收盤價,改變,交易量''' #TradeVolume,TradeValue,OpeningPrice,HighestPrice,LowestPrice,ClosingPrice,Change,Transaction
  單=單.split(',')
  outputwriter.writerow(單)

  for dataline in (data):
      outputwriter.writerow(dataline)
  outputfile.close()
  #在獲得股票資訊的csv檔過後，我們就可以開始著手準備訓練模型了！首先我們定義一個切分訓練及以及測試集的函式，函式的參數feature_data代表特徵的資料、label_data代表標籤的資料、length為訓練長度，也就是要以多長的feature去預測下一個label、split代表訓練集對於測試集的比例。

  #下一步要來建構RNN模型，我們直接引入keras.layer中的SimpleRNN做模型的建構。 建構完模型後，接著就要來做最重要的一步，那就是訓練模型啦！訓練模型的部分，筆者採用300個epochs以及10%的驗證集比例去做訓練，讀者可以嘗試去調整看看，說不定會得到更好的結果喔！

  #在將我們所需要的功能都寫成函式過後，接下來就只要一一呼叫他們就可以完成模型的訓練了。首先是讀取股票資料的csv檔，再來是區分訓練集以及測試集、建立模型、訓練模型。

  filename = "stock2021.csv"
  df = read_csv(filename, encoding = "big5")
  df
  ddtrain = df[["收盤價", "最高價", "最低價"]]
  ddprice = df[["收盤價"]]

  延展 = MinMaxScaler()
  展延 = MinMaxScaler()
  train_x, train_y, test_x, test_y = 載料(延展, 展延, ddtrain, ddprice, 10, 0.8)

  model = 建模()
  predict_y = 訓模(train_x, train_y, test_x, test_y)
  predict_y = 延展.inverse_transform([[i] for i in predict_y])
  test_y = 展延.inverse_transform(test_y)
  #最後我們利用python的plotly來繪製結果圖。先將預測結果以及實際結果放進dataframe中，再將dataframe以散佈圖的方式丟進plotly的函式，就可以得到一個圖表的html檔了！

  result = DataFrame({"predict": list(predict_y), "label": list(test_y)})
  result["predict"] = npArray(result["predict"]).astype("float64")
  result["label"] = npArray(result["label"]).astype("float64")

  data = [
    Scatter(y = result["predict"], name = "預測", line = dict(color = "blue", dash = "dot")),
    Scatter(y = result["label"], name = "收盤價", line = dict(color = "red"))
  ]
  plot({"data": data, "layout": Layout(title = "2021年台塑股票統計圖")}, auto_open = True)
