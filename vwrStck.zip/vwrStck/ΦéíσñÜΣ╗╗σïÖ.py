class MultiTaskModel(torch.nn.Module):
    def __init__(self, input_size, hidden_size):
        super().__init__()
        self.shared_lstm = torch.nn.LSTM(input_size, hidden_size, batch_first=True)
        self.reg_head = torch.nn.Linear(hidden_size, 1)  # 回歸任務：價格預測
        self.cls_head = torch.nn.Linear(hidden_size, 3)  # 分類任務：漲/跌/平
        
    def forward(self, x):
        lstm_out, _ = self.shared_lstm(x)
        last_out = lstm_out[:, -1, :]
        return self.reg_head(last_out), self.cls_head(last_out)

# 損失函數組合
def multi_task_loss(reg_output, cls_output, reg_target, cls_target):
    mse_loss = torch.nn.MSELoss()(reg_output, reg_target)
    ce_loss = torch.nn.CrossEntropyLoss()(cls_output, cls_target)
    return mse_loss + 0.5*ce_loss  # 加權求和
2. 對抗訓練增強魯棒性
class AdversarialTrainingWrapper:
    def __init__(self, model, epsilon=0.01):
        self.model = model
        self.epsilon = epsilon
        
    def adversarial_loss(self, inputs, labels):
        inputs.requires_grad = True
        outputs = self.model(inputs)
        loss = torch.nn.MSELoss()(outputs, labels)
        loss.backward()
        
        # 生成對抗樣本
        perturbation = self.epsilon * inputs.grad.sign()
        adv_inputs = inputs + perturbation
        
        # 計算對抗損失
        adv_outputs = self.model(adv_inputs)
        adv_loss = torch.nn.MSELoss()(adv_outputs, labels)
        
        return 0.5*loss + 0.5*adv_loss  # 混合損失

