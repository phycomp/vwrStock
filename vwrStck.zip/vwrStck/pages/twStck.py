from pandas import DataFrame
from datetime import datetime, timedelta
from stUtil import rndrCode
from altair import Chart, X, Y, Color, condition, value, Scale, layer#, Bar
from twstock import realtime as 即時, codes, Stock#, StockCodeInfo
from requests import get as rqstGET
from json import loads as jsnLoads
from streamlit import sidebar, session_state, radio as stRadio, columns as stCLMN, text_area, text_input, multiselect, pyplot, altair_chart, bar_chart, date_input
from streamlit import toggle as stToggle, markdown as stMarkdown #slider, dataframe, code as stCode, cache as stCache, 
from matplotlib.font_manager import fontManager
from matplotlib.pyplot import figure, bar, title, xlabel, ylabel, xticks, text, rcParams # 視覺化
from twstock import Stock, BestFourPoint

def 繪製均價(均價):
  #均價=DataFrame({'date': range(0, len(五日均價), 1), 'price': 五日均價}) O, N, Q, T, G encode(x='日期:D', y='Price:Q')
  rndrCode(均價)
  線圖 = Chart(均價, title='Price Daily Chart').mark_line().encode(x='日期:T', y='Price:Q').properties(width=600, height=400) #X('date:T').title('Date'), , scale=Scale(domain=[均價.price.min()*.8, 均價.price.max()*1.2])    set the size of chart color=alt.Color('line:N', legend=alt.Legend(orient='top',title='')), strokeWidth=alt.condition( "datum.line == 'Adj Close'", alt.value(2), alt.value(1)))
  return 線圖

MENU, 表單=[], ['各股比較', '比較', '股價', '四大賣點']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
各股=['0050', '0056', '009803', '009804', '2330']
股欄=['TradeVolume', 'TradeValue', 'OpeningPrice', 'HighestPrice', 'LowestPrice', 'ClosingPrice', 'Change', 'Transaction']  #'Date', 'Name', 
現日=datetime.today()

with sidebar:
  左, 右=stCLMN([1, 1])
  with 左:
    區間年=date_input('開始', 現日)#, '2023/05/13')
  with 右:
    區間月=date_input('結束', 現日, 'today')
  #單月=結束-開始     現日-timedelta(days=30)
  rndrCode([區間年, 區間月])
  #session_state.my_data_input = (date.today() - timedelta(days=10), date.today())
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  個股=multiselect('個股', 各股, default=各股[-1])
  個股欄位=stRadio('個股欄位', 股欄, horizontal=True, index=0)
  srch=text_input('搜尋', '0050')
if menu==len(表單):
  pass

elif menu==MENU[3]:
  if 個股:
    台積電 = Stock(個股[0])
    bfp = BestFourPoint(台積電)
    bfp.best_four_point_to_buy()    # 判斷是否為四大買點
    if bfp.best_four_point_to_sell():   # 判斷是否為四大賣點
      rndrCode(['是否為賣點', bfp.best_four_point()])           # 綜合判斷
      rndrCode(bfp.__dict__)
    當前個股=即時.get(個股[0])    # 擷取當前台積電股票資訊
    rndrCode(當前個股)
    多個股=twstock.realtime.get(['2330', '2337', '2409'])  # 擷取當前三檔資訊
    rndrCode(多個股)
elif menu==MENU[2]:
  if 個股:
    股 = Stock(個股[0])                             # 擷取台積電股價
    #stock = Stock('2330') 現日
    股.fetch_from(現日.year, 現日.month-1) #2024, 3
    價格=股.price
    五日均價=股.moving_average(價格, 5) #計算五日均價
    rndrCode(['五日均價', len(五日均價)])
    #均價=DataFrame(均價, columns=['price']) #'t' : range(0, len(均價), 1),)
    五日容量 = 股.moving_average(股.capacity, 5) #計算五日均量
    rndrCode(['五日容量', len(五日容量)])
    ma_p_cont = 股.continuous(五日均價) #計算五日均價持續天數
    五日乖離值 = 股.ma_bias_ratio(5, 10) #計算五日、十日乖離值
    rndrCode(['五日乖離值', len(五日乖離值)])
    股價={'容量':五日容量, '均價':五日均價} #'五日乖離值':五日乖離值, '日期': range(0, len(五日均價), 1), 
    資框=DataFrame(股價, columns=['容量', '均價'])
    #均價=繪製均價(五日均價)
    圖=繪製均價(資框)
    altair_chart(圖)
    #容量=繪製均價(五日容量)
    #altair_chart(line)
    #乖離=繪製均價(五日乖離值)
    #綜合=綜合
    #綜合=layer(均價, 容量, 乖離)
    #綜合
    #altair_chart(綜合)
    #rndrCode([五日均價, ma_c, ma_p_cont, ma_br])
    rndrCode([股.price, 股.capacity])
    #stock.data[0]   #Data(date=datetime(2017, 5, 18, 0, 0), capacity=22490217, turnover=4559780051, open=202.5, high=204.0, low=201.5, close=203.5, change=-0.5, transaction=6983)
    #台積電= Stock('2330') #[203.5, 203.0, 205.0, 205.0, 205.5, 207.0, 207.0, 203.0, 207.0, 209.0, 209.0, 212.0, 210.5, 211.5, 213.0, 212.0, 207.5, 208.0, 207.0, 208.0, 211.5, 213.0, 216.5, 215.5, 218.0, 217.0, 215.0, 211.5, 208.5, 210.0, 208.5]
    #rndrCode(['台積電', 台積電.__dict__]) # 列印 2330 證券編碼資料 StockCodeInfo(type='股票', code='2330', name='台積電', ISIN='TW0002330008', start='1994/09/05', market='上市', group='半導體業', CFI='ESVUFR')
    #rndrCode(stock)
    #[22490217, 17163108, 17419705, 23028298, 18307715, 26088748, 32976727, 67935145, 29623649, 23265323, 1535230, 22545164, 15382025, 34729326, 21654488, 35190159, 63111746, 49983303, 39083899, 19486457, 32856536, 17489571, 28784100, 45384482, 26094649, 39686091, 60140797, 44504785, 52273921, 27049234, 31709978]
    #rndrCode(codes)  # 列印台股全部證券編碼資料
    #台積電=codes['2330']
    #rndrCode([台積電, 台積電.name, 台積電.start])  # 2330 證券編碼資料 StockCodeInfo(type='股票', code='2330', name='台積電', ISIN='TW0002330008', start='1994/09/05', market='上市', group='半導體業', CFI='ESVUFR') 證券名稱台積電 2330 證券上市日期 1994/09/05
  #from twstock.proxy import SingleProxyProvider, configure_proxy_provider # 單一 Proxy
  #spr = SingleProxyProvider({'http': 'http://localhost:8080'})
  #configure_proxy_provider(spr)
  #from twstock.proxy import RoundRobinProxiesProvider # 多個 Proxy
  #proxies = [{'http': 'http://localhost:5000'}, {'http': 'http://localhost:5001'}]
  #rrpr=RoundRobinProxiesProvider(proxies)
  #twstock.proxy.configure_proxy_provider(rrpr)
  #another_proxies = [{'http': 'http://localhost:8000'}, {'https': 'https://localhost:8001'}] # 變更 Proxy 表
  #rrpr.proxies = another_proxies
elif menu==MENU[1]:
  fontManager.addfont('/home/josh/.local/share/fonts/魏碑體.TTC')
  rcParams['font.sans-serif']=['DFWeiBei-B5'] # 修改中文字體
  rcParams['axes.unicode_minus'] = False # 顯示負號
  資框=session_state['資框']
  #資框[個股欄位]
  rndrCode(資框.columns) #Index(['Date', 'Name', 'TradeVolume', 'TradeValue', 'OpeningPrice', 'HighestPrice', 'LowestPrice', 'ClosingPrice', 'Change', 'Transaction'], dtype='object')
  if 個股欄位:
    前十收盤價 = 資框.nlargest(10, 個股欄位, 'last')    #.astype('float')
  左, 右=stCLMN([2, 8])
  with 左:
    前十收盤價[['Name', 個股欄位]]
  with 右:
    #fig=figure(figsize=(15, 6))
    #bars = bar(前十收盤價['Name'], 前十收盤價[個股欄位], color='skyblue')   #'ClosingPrice'
    #title(f'前十{個股欄位}',fontsize=20)#Closing Prices
    #xlabel('Stock Name',fontsize=20)
    #ylabel(個股欄位,fontsize=20)    #'Closing Price'
    #xticks(fontsize=20, rotation=-90)
    # 在每個條形圖上顯示對應的股價
    #for bar in bars:
    #    yval = bar.get_height()
    #    text(bar.get_x() + bar.get_width()/2, yval, round(yval, 2), ha='center', va='bottom', fontsize=12)
    #pyplot(fig)
    #fig=Chart(前十收盤價).mark_bar().encode(x=前十收盤價['Name'], y=前十收盤價[個股欄位])   #, color='skyblue'
    #altair_chart(fig)
    bar_chart(前十收盤價, x='Name', y=個股欄位)   #, color="col3", columns=['Name', 個股欄位]
  #.encode( x="a", y="b", size="c", color="c", tooltip=["a", "b", "c"], fillOpacity=alt.condition(point_selector, alt.value(1), alt.value(0.3)),)
  #plt.show()
  #https://vocus.cc/article/667ebabbfd897800016b3086
elif menu==MENU[0]: #各類股
  url = 'https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL'
  res = rqstGET(url)
  杰森 = jsnLoads(res.text)
  資框 = DataFrame(杰森) # 將JSON數據轉換為DataFrame
  資框.set_index('Code', inplace=True) # 將"Code"列設置為索引
  資框.replace('', '0', inplace=True) # 將空字符串替換為0
  資框[資框.columns.difference(['Name'])] = 資框[資框.columns.difference(['Name'])].astype(float) # 將除了"Name"列以外的所有列轉換為浮點數
  if srch:
    資框[資框['Name'].str.contains(srch)]
  # 顯示DataFrame
  資框.loc[個股].T
  session_state['資框']=資框
