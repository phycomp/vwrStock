from pandas import read_sql
import sqlite3
from glob import glob

All_csv_file = glob('*.csv')
dbname = 'TWStock.db'   #連接到我們的資料庫，如果沒有的話會重新建一個
db = sqlite3.connect(dbname)
%%time
for 檔名 in All_csv_file:
    read_csv(檔名).iloc[:,1:].to_sql(檔名.replace('.csv',''),db,if_exists='replace')
在這邊我們直接用迴圈將每一個抓到的每日收盤資料當作一張張的表存進去sqlite資料庫檔案裡，我們對應的表單名就像”20140623″這樣的格式。

如何讀取資料庫的表格
我們這邊簡單介紹如何讀取sqlite檔案裡面的表格

read_sql(con=db,sql='SELECT * FROM "20180611"')

total_df = DataFrame()
for date in dates_list:
    資框 = read_sql(con=db,sql='SELECT * FROM' + ' "'+ date +'"')
    資框['Date'] = date
    total_df = total_df.append(資框)
total_df的shape(1203195,18)   #120萬行，18欄位。 接下來我們建立一個新的資料庫並取名叫’TWStock_2’。

dbname_2 = 'TWStock_2'
db2 = sqlite3.connect(dbname_2)
接下來我們利用groupby方法將我們的大表轉換成用股票代號來分的小表，並將一個個的小表存進去資料庫內
total_dict = dict(tuple(total_df.groupby('證券代號')))
for key in total_dict.keys():
    資框 = total_dict[key].iloc[:,2:]
    資框['Date'] = to_datetime(資框['Date'])
    資框 = 資框.sort_values(by=['Date'])
    資框.to_sql(key, db2, if_exists='replace')
