#提取股票清單
import pandas as p

data = p.read_table('本益比.txt', names=['股票', '股價', '漲跌', '漲跌幅', '本益比'], sep='		')
data = data['股票']
with open('股票清單.txt', 'a', encoding='utf-8') as f:
    for stock in data:
        f.write(f"{stock}\n")

#找出債務股本比
import pandas as p 
import yahoo_fin.stock_info as y
import warnings as w

w.filterwarnings('ignore')
data = p.read_table('股票清單.txt', names=['股票'])
data = data['股票']
name = []
number = []

#上市股:tw
#上櫃股:two
c = int(input("輸入數字\n查tw就按1\n查two就按2: ")) #框框
if c == 1:
    c = '.tw'
else:
    c = '.two'

for stock in data:
    stockid = stock[:4] + c
    name.append(stock)
    number.append(stockid)

#查1到10 第一個框框就打1 第二個框框就打10
#查某一個 例如查16 兩個框框都打16
a = int(input('從:')) - 1 #第一個框框
b = int(input('到:'))     #第二個框框

with open('債務股本比.txt', 'a', encoding='utf-8') as f:
    for stock, stockid in zip(name[a:b], number[a:b]):
        try:
            stats = y.get_stats(stockid)
            de = float(stats['Value'][46])

            f.write(f"{stock} {de}\n")
        except:
            continue

#找出最後結果  符合本益比<10倍和債務股本比<50%的股票
import pandas as p 
import warnings as w

p.options.display.max_rows = 1000 #結果可以顯示幾行
w.filterwarnings('ignore')
data1 = p.read_table('本益比.txt', names=['股票', '股價', '漲跌', '漲跌幅', '本益比'], sep='		')
data1 = data1[['股票', '股價', '本益比']]

data2 = p.read_table('債務股本比.txt', names=['股票', '債務股本比'], sep=' ')
data2 = data2[['債務股本比']]

data = p.concat([data1, data2], axis=1)

data = data.where( data['債務股本比'] < 50 )
data.sort_values(by=['股價'], inplace=True, ignore_index=True)
data.dropna(inplace=True)
data #列出全部
data.head(30) #列出裡面最便宜的30支股票
data.tail(30) #列出裡面最貴的30支股票
