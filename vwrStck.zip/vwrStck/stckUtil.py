import time
from stUtil import rndrCode
from datetime import datetime
from twstock import realtime as 即時

def rsi指標(data, window=14): # 計算14日RSI RSI 相對強弱指數
  delta = data.diff()
  gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
  loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
  rs = gain / loss
  rsi = 100 - (100 / (1 + rs))
  return rsi

def 監控股價(stock_code):
  while True:
    now = datetime.now().strftime("%H:%M:%S")
    即資 = 即時.get(stock_code)
    if 即資['success']:
        price = float(即資['realtime']['latest_trade_price'])
        rndrCode(f"[{now}] 當前股價: {price}")
        # 在此加入你的策略判斷（例如結合即時價格與歷史數據）
        # ...
    time.sleep(60)  # 每60秒更新一次
