import pandas as p
from bs4 import BeautifulSoup
import requests

data = p.read_html('https://isin.twse.com.tw/isin/C_public.jsp?strMode=2', encoding='big5hkscs', header=0)[0]
data = p.DataFrame(data['有價證券代號及名稱'])
data = data['有價證券代號及名稱'].astype(str)

def web(url):
    source = requests.get(url, headers={'Connection':'close'}) #連線到指定的網站
    soup = BeautifulSoup(source.content, 'lxml', from_encoding='utf-8') #讀取這個網頁的內容
    return soup #最終結果:回傳網頁內容

def result(dividend, price):
    yieldrate = round(dividend/price*100, 2) #殖利率 = 股利/股價 * 100%
    if yieldrate > 5: #殖利率>5%的股票  設定預算(殖利率>5%且股價<60的股票)寫法: if yieldrate > 5 and price < 60:
        print(f"{stock} {yieldrate}% 股價:{price} 股利:{dividend}")

for stock in data.iloc[1:964] :
    try:
        stockid = stock[:4]

        price_url = 'https://tw.stock.yahoo.com/quote/' + stockid #股價的網址
        dividend_url = 'https://tw.stock.yahoo.com/quote/' + stockid + '/dividend' #股利的網址

        span = web(price_url).find_all("span")
        for p in span:
            if p.text == '成交':
                price = float(span[span.index(p) + 1].string) #股價

        span = web(dividend_url).find_all("span", class_="")
        dividend = float(span[28].string) #2021股利
        result(dividend, price)
    except:
        continue
