# 設定全期間的日期
start_date = trend_data.index[0].strftime('%Y-%m-%d')
end_date = trend_data.index[-1].strftime('%Y-%m-%d')

# 迴圈讓逐檔個股標準化調整
for stk in stk_list:
    # 查詢全期的搜尋熱度值
    kw_list = [stk]
    pytrends.build_payload(kw_list, timeframe = start_date + ' ' + end_date)
    pytrends.interest_over_time()[stk]
    
    # 創立一個暫時性的 DataFrame，填入全期的搜尋熱度值
    temp_df = pd.DataFrame({'period': trend_data[stk]})
    temp_df['full_period'] = pytrends.interest_over_time()[stk]
    
    # 因為全期的搜尋，被限制只能取得月頻資料，因此我們要進行缺值填補的動作
    temp_df = temp_df.fillna(method = 'pad')
    
    # 全期的數值依據全期的最大值計算相對比例，在 Google Trend 的模式下也就是除以 100
    temp_df['full_period_ratio'] = temp_df.full_period / temp_df.full_period.max()
    
    # 進行原表格數據標準化調整，然後取代原表格數據
    temp_df['corrected_period'] = temp_df.period * temp_df.full_period_ratio
    trend_data[stk] = temp_df.corrected_period

# 看看最終的 Google Trends 搜尋熱度資料吧！
trend_data
