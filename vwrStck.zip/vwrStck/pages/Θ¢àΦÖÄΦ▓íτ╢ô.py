#The Ticker module The Ticker module, which allows you to access ticker data in a more Pythonic way:

from yfinance import Ticker, download, enable_debug_mode, Tickers, set_tz_cache_location#, yfinance  #pdr_override
from pandas import DataFrame
from stUtil import rndrCode
from streamlit import sidebar, multiselect, radio as stRadio, text_input

MENU, 表單=[], ['美股', '分析', '多股', '繪製']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  #欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[3]: #
  趣股 = ['MSFT', 'GOOGL', 'AMZN', 'TSLA']
  for 股  in 趣股:
    #多股 = stock_symbols[i]
    #多股 = active_symbol.strip()
    美股 = Ticker(股)
    股資=美股.info
    股資框=DataFrame.from_dict(股資, columns=股資.keys(), orient='index')#, index=None)
    #for k, v in 股資.items(): rndrCode([k, v])
    #股資框=DataFrame.from_dict(股資, orient='columns')
    股資框
    資框 = 美股.history(start="2025-05-06", end="2025-05-07")
    資框
  rndrCode(資框.columns)    #'Open', 'High', 'Low', 'Close', 'Volume', 'Dividends', 'Stock Splits'], dtype='object') 日期 開價 高價 低價 收價 成交量 股除 股交叉
  #股資=美股.info
  #for k, v in 股資.items():
  #  rndrCode([k, v])
    #{'Dividend Date': datetime.date(2024, 2, 15), 'Ex-Dividend Date': datetime.date(2024, 2, 9), 'Earnings Date': [datetime.date(2024, 5, 2), datetime.date(2024, 5, 6)], 'Earnings High': 1.62, 'Earnings Low': 1.46, 'Earnings Average': 1.51, 'Revenue High': 96598000000, 'Revenue Low': 87901000000, 'Revenue Average': 90988100000}
    #for row in 資框.itertuples(index=True):
    #  交易日 = row[0]
    #  交易日 = str(交易日.strftime('%Y%m%d'))
    #  開價 = row[1]
    #  開價 = str(開價)
    #  高價 = row[2]
    #  高價 = str(高價)
    #  低價 = row[3]
    #  低價 = str(低價)
    #  收價 = row[4]
    #  收價 = str(收價)
    #  成交量 = row[5]
    #  成交量 = str(成交量)
    #  股資 = [美股, 交易日, 開價, 高價, 低價, 收價, 成交量]
    #  rndrCode(股資)
    #fileObj.write(my_string + "\n")
elif menu==MENU[2]: #
  #Multiple tickers
  #To initialize multiple Ticker objects, use

  tickers = Tickers('微軟 aapl goog')

# access each ticker using (example)
  tickers.tickers['MSFT'].info
  tickers.tickers['AAPL'].history(period="1mo")
  tickers.tickers['GOOG'].actions
#To download price history into one table:

#import yfinance as yf
  data = download("SPY AAPL", period="1mo")
#download() and Ticker.history() have many options for configuring fetching and processing. Review the Wiki for more options and detail.
#Logging
#yfinance now uses the logging module to handle messages, default behaviour is only print errors. If debugging, use enable_debug_mode() to switch logging to debug with custom formatting.
#Smarter scraping
#To use a custom requests session (for example to cache calls to the API or customize the User-agent header), pass a session= argument to the Ticker constructor.

#import requests_cache
#session = requests_cache.CachedSession('yfinance.cache')
#session.headers['User-agent'] = 'my-program/1.0'
  ticker = Ticker('微軟') #, session=session)
# The scraped response will be stored in the cache
  ticker.actions
#Combine a requests_cache with rate-limiting to avoid triggering Yahoo's rate-limiter/blocker that can corrupt data.

#from requests import Session
#from requests_cache import CacheMixin, SQLiteCache
#from requests_ratelimiter import LimiterMixin, MemoryQueueBucket
#from pyrate_limiter import Duration, RequestRate, Limiter
#class CachedLimiterSession(CacheMixin, LimiterMixin, Session):
#    pass
#
#session = CachedLimiterSession(
#    limiter=Limiter(RequestRate(2, Duration.SECOND*5)),  # max 2 requests per 5 seconds
#    bucket_class=MemoryQueueBucket, backend=SQLiteCache("yfinance.cache"),
#)
#Managing Multi-Level Columns
#The following answer on Stack Overflow is for How to deal with multi-level column names downloaded with yfinance?
#yfinance returns a pandas.DataFrame with multi-level column names, with a level for the ticker and a level for the stock price data
#The answer discusses:
#How to correctly read the the multi-level columns after saving the dataframe to a csv with pandas.DataFrame.to_csv
#How to download single or multiple tickers into a single dataframe with single level column names and a ticker column
#pandas_datareader override
#If your code uses pandas_datareader and you want to download data faster, you can "hijack" pandas_datareader.data.get_data_yahoo() method to use yfinance while making sure the returned data is in the same format as pandas_datareader's get_data_yahoo().

#from pandas_datareader import data as pdrData

#yfinance() # <== that's all it takes :-)
  apple = Ticker("AAPL")
  apple_cot = apple.history(start = "2024-01-01", end= "2024-10-10")
  apple_cot
#data = pdrData.get_data_yahoo("SPY", start="2017-01-01", end="2017-04-30") # download dataframe
#Timezone cache store When fetching price data, all dates are localized to stock exchange timezone. But timezone retrieval is relatively slow, so yfinance attemps to cache them in your users cache folder. You can direct cache to use a different location with set_tz_cache_location():
  set_tz_cache_location("custom/cache/location")
elif menu==MENU[1]: #
  pass
  微軟.income_stmt
  微軟.quarterly_income_stmt
  # - balance sheet
  微軟.balance_sheet
  微軟.quarterly_balance_sheet
  # - cash flow statement
  微軟.cashflow
  微軟.quarterly_cashflow
# see `Ticker.get_income_stmt()` for more options

# show holders
#微軟.major_holders
#微軟.institutional_holders
#微軟.mutualfund_holders

# Show future and historic earnings dates, returns at most next 4 quarters and last 8 quarters by default.
# Note: If more are needed use 微軟.get_earnings_dates(limit=XX) with increased limit argument.
#微軟.earnings_dates

# show ISIN code - *experimental*
# ISIN = International Securities Identification Number
#微軟.isin

# show options expirations
#微軟.options

# show news
#微軟.news

# get option chain for specific expiration
#opt = 微軟.option_chain('YYYY-MM-DD')
# data available via: opt.calls, opt.puts
#If you want to use a proxy server for downloading data, use:

  微軟 = Ticker("MSFT")
  #微軟.history(..., proxy="PROXY_SERVER")
  微軟.get_actions(proxy="PROXY_SERVER")
  微軟.get_dividends(proxy="PROXY_SERVER")
  微軟.get_splits(proxy="PROXY_SERVER")
  微軟.get_capital_gains(proxy="PROXY_SERVER")
  微軟.get_balance_sheet(proxy="PROXY_SERVER")
  微軟.get_cashflow(proxy="PROXY_SERVER")
  #微軟.option_chain(..., proxy="PROXY_SERVER")

elif menu==MENU[0]: #美股
  pass
  微軟 = Ticker("MSFT")
  #微軟.info # get all stock info
  #rndrCode([])
  hist = 微軟.history(period="1mo") # get historical market data
  微軟.history_metadata # show meta information about the history (requires history() to be called first)
  微軟.actions # show actions (dividends, splits, capital gains)
  微軟.dividends
  微軟.splits
  微軟.capital_gains  # only for mutual funds & etfs
  微軟.get_shares_full(start="2022-01-01", end=None) # show share count

# show financials:
# - income statement
