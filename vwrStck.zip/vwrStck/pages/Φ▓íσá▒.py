#!/usr/bin/env python
from 股報表 import 財報表
from streamlit import sidebar, multiselect, radio as stRadio, text_input

MENU, 表單=[], ['財報', '', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  #欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
elif menu==MENU[0]: #財報
  pass
  股資框 = 財報表(2017, 2, type='營益分析查詢彙總表')
  股資框[股資框['公司名稱']=='台泥']
  股資框

