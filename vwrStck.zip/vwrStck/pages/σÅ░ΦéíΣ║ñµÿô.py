import requests
from pandas import read_csv
import io
import re
import time
from datetime import datetime, timedelta, time
from twstock import Stock
from fxcmpy import fxcmpy, fxcmpy_tick_data_reader as tdr

def crawler(date_time):
    page_url = 'http://www.twse.com.tw/exchangeReport/MI_INDEX?response=csv&amp;date=' + date_time +'&amp;type=ALLBUT0999'
    page = requests.get(page_url)
    use_text = page.text.splitlines()
    for i,text in enumerate(use_text):
        if text == '"證券代號","證券名稱","成交股數","成交筆數","成交金額","開盤價","最高價","最低價","收盤價","漲跌(+/-)","漲跌價差","最後揭示買價","最後揭示買量","最後揭示賣價","最後揭示賣量","本益比",':
            initial_point = i
            break
    test_df = pd.read_csv(io.StringIO(''.join([text[:-1] + '\n' for text in use_text[initial_point:]])))
    test_df['證券代號'] = test_df['證券代號'].apply(lambda x:x.replace('"',''))
    test_df['證券代號'] = test_df['證券代號'].apply(lambda x: x.replace('=',''))

    return test_df
def trans_date(date_time):
    return ''.join(str(date_time).split(' ')[0].split('-'))

def parse_n_days(start_date,n): #抓好幾天
    df_dict = {}
    now_date = start_date
    for i in range(n):
        time.sleep(5)
        now_date = now_date - timedelta(days=1)
        try:
            df = crawler(trans_date(now_date))
            print("Current date" + trans_date(now_date))
            df_dict.update({trans_date(now_date):df})
            print('Successful!!')
        except:
            print('Fails at' + str(now_date))
    return df_dict

from streamlit import sidebar, multiselect, radio as stRadio, text_input

MENU, 表單=[], ['股價分析', '', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
elif menu==MENU[0]: #股價分析
  台積電='2330'
  個股 = Stock(台積電)
  股價 = 個股.fetch_31()
  api = fxcmpy.fxcmpy(access_token=API_key, server='demo')
  rndrCode(tdr.get_available_symbols())
  起始 = datetime(2018, 2, 1)
  結束 = datetime(2018, 2, 15)
  區間 = tdr('EURUSD', 起始, 結束)
  區間.get_data().head()
