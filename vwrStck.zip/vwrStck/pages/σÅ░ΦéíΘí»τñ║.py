from requests import post as rqstPOST
from datetime import datetime
from stUtil import rndrCode
from io import StringIO
from pandas import read_csv, to_numeric
import numpy as np
from streamlit import multiselect, sidebar, columns as stCLMN, radio as stRadio, text_input, tabs as stTAB, data_editor, session_state, date_input, dataframe

MENU, 表單=[], ['台股當日', '客戶', '服務', '整合', '成本', '正則', '項目', '客戶/美療師', '地圖', '預約', '金流', '蘆洲', '輪播', 'oauth', '登入'] #訂單, cart購物車
當日=datetime.today()
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
股欄=['證券代號', '證券名稱', '成交股數', '成交筆數', '成交金額', '開盤價', '最高價', '最低價', '收盤價', '漲跌(+/-)', '漲跌價差', '最後揭示買價', '最後揭示買量', '最後揭示賣價', '最後揭示賣量', '本益比', 'Unnamed: 16']
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  srch=text_input('搜尋', '')
  欄股=multiselect('股市欄位', 股欄)
  現日=date_input('當日', 當日.date())
if menu==len(表單):
  pass
elif menu==MENU[3]:    #創新
  pass
  #from 眼科.創新 import 創新
elif menu==MENU[2]:    #想法
  pass
  #from 眼科.想法 import 想法
elif menu==MENU[1]:    #卓越
  #from 眼科.卓越 import 卓越
  pass
elif menu==MENU[0]:    #示範
  #from 眼科.示範 import 示範
  if 現日:
    #現=現日.strftime("%Y-%b-%d")
    #現=現日.replace('-', '')
    #datestr = '20180131'
    del session_state['現日']
    if '現日' not in session_state: session_state['現日']=set()
    if 現日 in session_state['現日']:
      for 日 in session_state['現日']: rndrCode(日)
      股框=session_state[f'股框{現日}']#=資框[資框['證券代號'].notna()]
      #股框 = 股框.apply(lambda s: to_numeric(s.astype(str).str.replace(",", "").replace("+", "1").replace("-", "-1"), errors='coerce')) # 整理一些字串：
    else:
      session_state['現日'].add(現日)
      結果=rqstPOST(f'https://www.twse.com.tw/exchangeReport/MI_INDEX?response=csv&date={現日}&type=ALL') # 下載股價
      for 資 in 結果.raw:
        rndrCode(資)
      #rndrCode(dir(結果.raw))   #'auto_close', 'chunk_left', 'chunked', 'close', 'closed', 'connection', 'data', 'decode_content', 'drain_conn', 'enforce_content_length', 'fileno', 'flush', 'get_redirect_location', 'getheader', 'getheaders', 'geturl', 'headers', 'info', 'isatty', 'isclosed', 'json', 'length_remaining', 'msg', 'read', 'read1', 'read_chunked', 'readable', 'readinto', 'readline', 'readlines', 'reason', 'release_conn', 'retries', 'seek', 'seekable', 'shutdown', 'status', 'stream', 'supports_chunked_reads', 'tell', 'truncate', 'url', 'version', 'version_string', 'writable', 'writelines'
      #for 資 in 結果: rndrCode(資)    #dir(結果)
      資框=read_csv(StringIO(結果.text.replace("=", "")), header=["證券代號" in l for l in 結果.text.split("\n")].index(True)-1) # 整理資料，變成表格
      #rndrCode([資框.columns ])
      資框
      股框=session_state[f'股框{現日}']=資框[資框['證券代號'].notna()]
      #股框 = 股框.apply(lambda s: to_numeric(s.astype(str).str.replace(",", "").replace("+", "1").replace("-", "-1"), errors='coerce')) # 整理一些字串：
    股框[欄股]  #資框[]
      #dataframe(欄股資) # 顯示出來
