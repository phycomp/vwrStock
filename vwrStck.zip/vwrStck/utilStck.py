from datetime import datetime, date, timedelta
from pandas import set_option, concat
from stUtil import rndrCode
import numpy as np
from matplotlib.pyplot import title, legend
from yfinance import Ticker, download as 財經下載
from requests import get as rqstGET
from streamlit import dataframe
from bs4 import BeautifulSoup
#from pandas_datareader import data #導入pandas_datareader
#from yfinance import Ticker #導入fix_yahoo_finance

def 財報(year, season, type='綜合損益彙總表'):
    if year >= 1000: year -= 1911
        
    if type == '綜合損益彙總表': url = 'http://mops.twse.com.tw/mops/web/ajax_t163sb04'
    elif type == '資產負債彙總表': url = 'http://mops.twse.com.tw/mops/web/ajax_t163sb05'
    elif type == '營益分析彙總表': url = 'http://mops.twse.com.tw/mops/web/ajax_t163sb06'
    else: print('type does not match')
    回應 requests.post(url, { 'encodeURIComponent':1, 'step':1, 'firstin':1, 'off':1, 'TYPEK':'sii', 'year':'103', 'season':'01', })
    回應encoding = 'utf8'
    資框全 = read_html(回應text)
    for i, df in enumerate(資框全):
        資框.columns = 資框.iloc[0]
        資框全[i] = 資框.iloc[1:]
    資框 = concat(資框全).applymap(lambda x: x if x != '--' else np.nan)
    資框 = 資框[資框['公司代號'] != '公司代號']
    資框 = 資框[~資框['公司代號'].isnull()]
    return 資框

def 網頁股資(url):
  回應 = rqstGET(url, headers={'Connection':'close'}) #連線到指定的網站
  soup = BeautifulSoup(回應.content, 'lxml', from_encoding='utf-8') #讀取這個網頁的內容
  return soup #最終結果:回傳網頁內容

def 計算殖率(股利, 股價):
  殖利率 = round(股利/股價*100, 2) #殖利率 = 股利/股價 * 100%
  if 殖利率 > 5 and 股價 < 60: #殖利率>5%的股票  設定預算(殖利率>5%且股價<60的股票)寫法: if 殖利率 > 5 and 股價 < 60:
    rndrCode(f"{stock} {殖利率}% 股價:{股價} 股利:{股利}")

def 繪均線(個股): #畫個股1，5，20，60日平均線 #設定爬蟲股票代號
  #sid = '2330'
  開始 = datetime.now() - timedelta(days=180) #設定爬蟲時間，以日為單位
  結束 = date.today() #把資料抓到本機
  #yf.pdr_override()
  股=Ticker(個股) # 取得股票資料，上櫃就改成.TWO
  #股 = Ticker(股碼)
  symbol, 區間='TSLA', '1h'
  股資 = 股.history(start=開始, end=結束)
  #股資 = 股.history(period='1d', interval=區間)
  set_option('display.max_columns', None)
  set_option('display.width', None)
  rndrCode(f"Historical Data for {symbol} from {start_date} to {end_date}")

  formatted_data = concat([historical_data.head(), historical_data.tail()])
  #print(tabulate(formatted_data, headers='keys', tablefmt='psql'))

  #print("\nShowing only the first and last 5 rows of data:")
  #print(tabulate(formatted_data, headers='keys', tablefmt='grid'))
  台積電 = Ticker('2330.TW')
  dataframe(台積電.info).T
  股資 = 財經下載(f'{個股}.TW', 開始, 結束)
  #股.tail(10) #如果加上如下這段就會畫出圖形 #線型圖，收盤價、5日均線、20日均線、60日均線
  #Open, High, Low, Close,Volume, Dividends, Stock Splits
  dataframe(股資)
  #rndrCode([股資])
  股資['Close'].plot(figsize=(16, 8))
  股資['Close'].rolling(window=5).mean().plot(figsize=(16, 8), label='5_Day_Mean')
  股資['Close'].rolling(window=20).mean().plot(figsize=(16, 8), label='20_Day_Mean')
  股資['Close'].rolling(window=60).mean().plot(figsize=(16, 8), label='60_Day_Mean') #顯示側標
  legend(loc='upper right', shadow=True, fontsize='x-large') #顯示標題
  title(個股) #畫個股收盤價及成交量
