from requests import post as rqstPOST
from pandas import read_html
from io import StringIO
#numpy as np import 
from streamlit import sidebar, multiselect, radio as stRadio, text_input
from 綜合分析 import 損益表

MENU, 表單=[], ['綜合損益表', '財務報表', '總表']	#, '錯綜複雜', '二十四節氣'
總表={'財務表':'https://mops.twse.com.tw/mops/web/t51sb02', '綜合損益表':'http://mops.twse.com.tw/mops/web/ajax_t163sb04', '資產負債表':'http://mops.twse.com.tw/mops/web/ajax_t163sb05', '營益分析查詢彙總表':'http://mops.twse.com.tw/mops/web/ajax_t163sb06'}
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  #欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  表=stRadio('股市欄位', 總表.keys(), horizontal=True, index=0)
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[2]: #
  from 總表 import 財務分析年度
  if 表:
    表址=總表.get(表)   #exchange='sii', 
    股資, 股資框=財務分析年度(110, 1, 表址=表址)
    股資
    股資框
elif menu==MENU[1]: #
  pass
  from 財務爬蟲 import 財務報表
  year, season, kind=109, 1, '綜合損益彙總表'
  財務報表(year, season, kind)
elif menu==MENU[0]: #綜合損益表
  pass
  year, season, kind=109, 1, '綜合損益彙總表'
  url = 'https://mops.twse.com.tw/mops/web/ajax_t163sb05'
  回應=rqstPOST(url, {'encodeURIComponent':1, 'step':1, 'firstin':1, 'off':1, 'TYPEK':'sii', 'year':str(year), 'season':str(season)})
  回應.encoding = 'utf8'
  股資框 = read_html(StringIO(回應.text), header=0) #encoding='utf-8', 
  kind='營益分析彙總表'
  url = 'https://mops.twse.com.tw/mops/web/ajax_t163sb06'
  回應 = requests.post(url, { 'encodeURIComponent':1, 'step':1, 'firstin':1, 'off':1, 'TYPEK':'sii', 'year':str(year), 'season':str(season), })
  股資框 = read_html(StringIO(r.text), header=None)
  #dfs1[0].iloc[:18,:]
  股資框[0][股資框['0'].str.contains('公司代號')]
  股資框=損益表(year, season, type=kind)
