import requests
from stUtil import rndrCode
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from utilStck import 財報
from streamlit import sidebar, multiselect, radio as stRadio, text_input
MENU, 表單=[], ['財報', '分析', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
elif menu==MENU[0]: #財報
  pass
  資框 = 財報(107, 2, '營益分析彙總表')
  資框 = 資框.drop(['合計：共 808 家'], axis=1)
  資框 = 資框.set_index(['公司名稱'])
  資框 = 資框.astype(float)
  資框['毛利率(%)(營業毛利)/(營業收入)'].hist(bins=range(-100,100))
  資框.loc['台積電']
  資框.loc[['台積電', '聯發科']]
  #數值分析
  #資框.discribe()
  資框['毛利率(%)(營業毛利)/(營業收入)'].hist(bins=range(-100,100))
  條件1=資框['毛利率(%)(營業毛利)/(營業收入)'].astype(float) > 20
  條件2=資框['營業利益率(%)(營業利益)/(營業收入)'].astype(float) > 5
  資框[條件1 & 條件2]
  rndrCode(資框)
