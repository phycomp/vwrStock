from requests import post as rqstPOST, get as rqstGET
from io import StringIO
from streamlit import dataframe
from numpy import array as npArray
from bs4 import BeautifulSoup
from stUtil import rndrCode
from pandas import DataFrame

#url = 'https://mops.twse.com.tw/mops/web/t51sb02'
#總表={'綜合損益表':'http://mops.twse.com.tw/mops/web/ajax_t163sb04', '資產負債表':'http://mops.twse.com.tw/mops/web/ajax_t163sb05', '營益分析查詢彙總表':'http://mops.twse.com.tw/mops/web/ajax_t163sb06'}
            

def 財務分析年度(year, season, exchange='sii', 表址=None):   #get_FinancialAnalysisIndex_year
  #表址=總表.get(表類)
  rndrCode(表址)
  表典={'encodeURIComponent':1, 'run':'Y', 'step':1, 'TYPEK':exchange, 'year':year, 'firstin':1, 'off':1, 'ifrs':'Y'}
  #表典={'encodeURIComponent':1, 'run':'Y', 'step':1, 'TYPEK':'sii', 'year':year, 'firstin':1, 'off':1, 'ifrs':'Y'} #otc
  #表典={'encodeURIComponent':1, 'step':1, 'firstin':1, 'off':1, 'TYPEK':exchange, 'year':year, 'season':season}
  #if stock_or_otc == 'OTC': 表典['TYPEK'] = 'otc'

  股資=總表分析(表址, 表典) #get_data_from_mops_twse
  股資框=DataFrame(股資, columns=['Number', 'Name', 'DebtAssetRatio', 'LongTermFundsRealEstateRatio', 'CurrentRatio', 'QuickCurrentRatio', 'InterestProtectionMutiple', 'AccountsReceivableTurnover', 'AverageDaysOfCashCollection', 'InventoryTurnoverRate', 'AverageSalesDays', 'AverageSalesRealEstateTurover', 'TotalAssetsWeekTurnover', 'ROA', 'ROE', 'NetProfitBeforeTaxAccountForPaid-inCapitalTheRatio', 'NetProfitRatio', 'EPS', 'CashFlowRatio', 'CashFlowAllowableRatio', 'CashReinvestmentCapitalRatio']   #npArray()
                    )
  #print(df)
  return 股資, 股資框

def 總表分析(url, 表典):   #get_data_from_mops_twse
    回應 = rqstGET(url, 表典)  #requests.post
    回應.encoding = 'utf8'
    soup = BeautifulSoup(StringIO(回應.text), 'html.parser')  #html5lib
    rndrCode(soup)
    tables = soup.find_all("table", {"class" : "hasBorder"})
    rndrCode(['tables=', tables])
    data = []
    for tb in tables:
        for row in tb.find_all("tr"):
            #print(row.text)
            tempdata = []
            for col in row.find_all('td'):
                col.attrs = {}
                #print(col.text.strip().replace('\u3000', ''))
                tempdata.append(col.text.strip().replace('\u3000', ''))
            if len(tempdata) <= 1: pass
            else:
                data.append(tempdata)
                #print(tempdata)
    return data
