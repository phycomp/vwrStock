from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, LSTM, Dense, Concatenate
from shap import DeepExplainer, summary_plot     #2. 特征重要性分析 (使用SHAP值)

def 機器學習(): # 輸入層設計
  ts_input = Input(shape=(30, 5), name='price_sequence')  # 30天歷史序列: 開盤價/最高價/最低價/收盤價/成交量
  macro_input = Input(shape=(4,), name='macro_factors')   # 當日宏觀因子: SOX漲跌幅/NASDAQ漲跌幅/匯率/VIX

  lstm_layer = LSTM(64)(ts_input) # 時間序列特征提取

  dense_macro = Dense(16, activation='relu')(macro_input) # 全連接層處理宏觀因子

  combined = Concatenate()([lstm_layer, dense_macro]) # 特征融合

# 輸出層
  output = Dense(3, activation='softmax')(combined)  # 3類: 上漲/持平/下跌

  model = Model(inputs=[ts_input, macro_input], outputs=output)
  model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# 創建解釋器
譯器 = DeepExplainer(model, [X_train_ts, X_train_macro])

# 計算SHAP值
shap_values = 譯器.shap_values([X_sample_ts, X_sample_macro])

# 可視化宏觀因子影響
shap.summary_plot(shap_values[1], X_sample_macro, feature_names=['SOX_chg', 'NASDAQ_chg', 'USD/TWD', 'VIX'])
