from stUtil import rndrCode
from pandas import read_html
from requests import get as rqstGET
from streamlit import sidebar, session_state, radio as stRadio, columns as stCLMN, text_area, text_input, multiselect
from streamlit import toggle as stToggle, markdown as stMarkdown #slider, dataframe, code as stCode, cache as stCache, 

趣股={'2330':'台積電', '1215':'群峰'}
股欄=list(趣股.keys())
MENU, 表單=[], ['代碼', '', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
elif menu==MENU[0]: #代碼
  pass
  URL='https://isin.twse.com.tw/isin/C_public.jsp?strMode=2'
  回溯=rqstGET(URL)
  #response=回溯.text
  資框=read_html(回溯.text)
  資框[0]
  #rndrCode()
