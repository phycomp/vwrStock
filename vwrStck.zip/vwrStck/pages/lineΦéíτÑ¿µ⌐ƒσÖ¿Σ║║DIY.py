#!/usr/bin/env python
import twstock
from pandas import DataFrame
from stUtil import rndrCode
from streamlit import sidebar, multiselect, radio as stRadio, text_input

MENU, 表單=[], ['均價', '趨勢', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[2]: #
  get_ipython().run_line_magic('pylab', 'inline')
  個股 = Stock('2002')
  data = 個股.fetch(2017, 1)
  資框 = DataFrame.from_dict(data)
  for m in range(2, 12):
      data = 個股.fetch(2017, m)
      資框_tmp = DataFrame.from_dict(data)
      資框 = 資框.append(資框_tmp)

  資框 = 資框.set_index('date')
  資框
  get_ipython().run_line_magic('pylab', 'inline')
  import twstock
  import pandas as pd

  廿日 = 20

  資框['ma'] = 資框['close'].rolling(window=廿日).mean()
  資框['std'] = 資框['close'].rolling(window=廿日).std()
  資框['up_band'] = 資框['ma']+資框['std']*2
  資框['down_band'] = 資框['ma']-資框['std']*2

  # 買點
  chk_b1 = 資框['close']<資框['down_band']
  b1 = 資框[chk_b1]
  rndrCode('buy point:', len(b1))
  #b1

  # 賣點
  chk_s1 = 資框['close']>資框['up_band']
  s1 = 資框[chk_s1]
  rndrCode('sell point:', len(s1))
  #s1

  資框[['close', 'ma', 'up_band', 'down_band']].plot(grid = True, figsize=[15,10])

  # 點出買賣點
  from matplotlib.pyplot import scatter, title, legend
  l1 = scatter(s1.index, s1['close'], marker='o', color='red', label='sell')
  l2 = scatter(b1.index, b1['close'], marker='d', color='green', label='buy')

  title('[%s] with 2*std' %(stock.sid))
  legend()

  #show()


  # In[5]:


  # pip install twstock pandas matplotlib pymongo

  get_ipython().run_line_magic('pylab', 'inline')

  元大50='0050'
  元大 = Stock(元大50)
  data = 元大.fetch(2017, 1)
  資框 = DataFrame.from_dict(data)

  for m in range(2, 12):
      data = 元大.fetch(2017, m)
      資框_tmp = DataFrame.from_dict(data)
      資框 = 資框.append(資框_tmp)

  資框 = 資框.set_index('date')

  # pip install twstock pandas matplotlib
  get_ipython().run_line_magic('pylab', 'inline')

  廿日 = 20
  資框['ma'] = 資框['close'].rolling(window=廿日).mean()
  資框['std'] = 資框['close'].rolling(window=廿日).std()
  資框['up_band'] = 資框['ma']+資框['std']*2
  資框['down_band'] = 資框['ma']-資框['std']*2

  # 買點
  chk_b1 = 資框['close']<資框['down_band']
  b1 = 資框[chk_b1]
  rndrCode('buy point:', len(b1))
  #b1

  chk_s1 = 資框['close']>資框['up_band'] # 賣點
  s1 = 資框[chk_s1]
  rndrCode('sell point:', len(s1))
  #s1

  資框[['close', 'ma', 'up_band', 'down_band']].plot(grid = True, figsize=[15,10])

  # 點出買賣點
  l1 = scatter(s1.index, s1['close'], marker='o', color='red', label='sell')
  l2 = scatter(b1.index, b1['close'], marker='d', color='green', label='buy')

  title('[%s] with 2*std' %(stock.sid))
  legend()
  show()
elif menu==MENU[1]: #
  pass
  from linebot import LineBotApi, WebhookParser
  from linebot.exceptions import InvalidSignatureError
  from linebot.models import *

  channel_secret = 'your channel_secret'
  channel_access_token = 'your channel_access_token'
  line_bot_api = LineBotApi(channel_access_token)
  #push message to one user
  user_id = 'your user_id'
  line_bot_api.push_message(user_id, TextSendMessage(text='Hello World!'))
  line_bot_api.reply_message event.reply_token, TextSendMessage(text=event.message.text)

#改為：
  text=event.message.text
  #userId = event['source']['userId']
  if text.lower()=='me':
    content = str(event.source.user_id)
    line_bot_api_8.reply_message(event.reply_token, TextSendMessage(text=content))
  else: line_bot_api_8.reply_message(event.reply_token, TextSendMessage(text=text))
elif menu==MENU[0]: #均價
  from twstock import Stock
  台積電='2330'
  stock = Stock(台積電)
  rndrCode('high', stock.date[-5:])    # 近五日
  rndrCode('price', stock.price[-5:])  # 近五日之收盤價
  rndrCode('high', stock.high[-5:])    # 近五日之盤中高點
# coding: utf-8

# # line 股票 bot
#

# - 報價
# ![Imgur](https://i.imgur.com/FXr8DED.png)
#
# - 畫出最近一個月的折線圖
# ![Imgur](https://i.imgur.com/XnwkGDY.png)
#

# ## 申請 line developer trial
# - 沒申請也ok，只是沒有推送功能可用
# - developer trial只可以有50個好友
#
# ### 目前由中文官方網頁申請 line@帳號開啟API預設沒有developer trial項可以選
# 要改由 https://developers.line.me/en/ 進去申請才行
# 如此頁面的介紹： http://at-blog.line.me/tw/create_developer_trial
#
# - 申請結束，要把「Channel secret」、「Channel access token」複製到程式中，此為收送訊息需要的
# - 接著編輯「Use webhooks」欄位，改為「Enabled」
# - 加入「Webhook URL」，以我的為例為「mybot.herokuapp.com/callback_yangbot8」
# - 「Auto-reply messages」改為disable
# - 掃一下這一個line-bot的bar-code，把它加入好友
#
# - 接著參考這一篇打造一個echo bot:
#   https://github.com/line/line-bot-sdk-python/tree/master/examples/flask-echo
# - line API的參考文件：
#   https://developers.line.me/en/docs/messaging-api/reference/#image
# - 測試會動了之後，請在程式中69~73行改為加入這一段，為主動發送訊息的測試做準備

# In[ ]:


#原來：


# In[1]:


# 測試一下 Line-bot-sdk 的主動推播訊息
# pip install line-bot-sdk

#- push message test


# ## 取得股票資訊
# - 使用twstock套件
#
#

# In[7]:


# 要先安裝twstock
# pip install twstock



# Stock 預設建立時會取得近 31 日開盤之資料


# In[6]:




# In[10]:




# # 即時股價

# In[5]:




# In[9]:



# In[10]:




# In[13]:


  個股 = Stock(台積電)
  data = 個股.fetch(2017, 11)
  資框 = DataFrame.from_dict(data)
  資框
  fro twstock import realtime as 即時
  即價 = 即時.get('2002')
  即價['realtime']['latest_trade_price']  # 最新股價
  即價 = 即時.get('2002')
  即價
  from datetime import datetime
  時刻 = datetime.fromtimestamp(即價['timestamp'])
  時刻.strftime('%Y-%m-%d %H:%M:%S')
  時刻 = datetime.fromtimestamp(stock_rt['timestamp']+8*60*60)
  時刻.strftime('%Y-%m-%d %H:%M:%S')


# In[14]:




# ## 開始分析吧!~
#

# In[3]:


# pip install twstock pandas matplotlib pymongo


# ## 來個基本的BBand吧

# In[4]:


# pip install twstock pandas matplotlib


# # **發佈app到Heroku的補充教材
#   --> 如果有人不知道怎麼發佈，可以參考一下

# - 新增一個app
# ![Imgur](https://i.imgur.com/UnADtKg.png)
#
# - 填入project anme
# ![Imgur](https://i.imgur.com/zPsv9DG.png)
#
#
# - 設定要用dropbox
# ![Imgur](https://i.imgur.com/GklIaFq.png)
#
# - 連接
# ![Imgur](https://i.imgur.com/qLsxpn4.png)
#
#
# - heroku會在dropbox上建一個資料夾，拉進去就好
# ![Imgur](https://i.imgur.com/z6t4kkN.png)
#
#
# - 發佈
# ![Imgur](https://i.imgur.com/DKwlXLp.png)
# - 發佈過程圖片
# ![Imgur](https://i.imgur.com/VNS7sEh.png)
#
#
# - 發佈完，點一下open，看是否正常運作
# ![Imgur](https://i.imgur.com/LtfnnT7.png)
# - 看來是ok了
# ![Imgur](https://i.imgur.com/GePSeee.png)
#
#
# - 在Heroku中的Settings中可以看到你的網址 or 剛剛的open頁面也有
# ![Imgur](https://i.imgur.com/5YcFQnl.png)
#
#
# - 因為我們的webhook的callback function是在/callback_bot8，所以如圖
# ![Imgur](https://i.imgur.com/fKbzkAB.png)
#
#
#
