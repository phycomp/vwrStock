# -*- coding: utf-8 -*-
from streamlit import sidebar, multiselect, radio as stRadio, text_input
from stUtil import rndrCode
from datetime import datetime, timedelta
import concurrent.futures
#from flask import Flask, render_template, jsonify
from twstock.stock import Stock
from twstock.analytics import BestFourPoint
from 買賣訊號 import 買賣

趣股 = [
    '2330',  # 台積電
    '2317',  # 鴻海
    '1301',  # 台塑
    '1326',  # 台化
    '2412',  # 中華電
    '3008',  # 大立光
    '1303',  # 南亞
    '2308',  # 台達電
    '2454',  # 聯發科
    '2881',  # 富邦金
    '8299']  #群聯
    #'6223'  # 旺矽

個股={'2330':u'台積電', '2317':u'鴻海', '1301':u'台塑', '1326':u'台化', '2412':u'中華電', '3008':u'大立光', '1303':u'南亞', '2308':u'台達電', '2454':u'聯發科', '2881':u'富邦金', '8299':u'群聯', '6223':u'旺矽'}
MENU, 表單=[], ['買賣訊號', '', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  股=multiselect('個股', 個股)  #, default=個股.keys()[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
elif menu==MENU[0]: #買賣訊號
  pass
  rndrCode(趣股)
  結果=買賣(趣股) #render_template('stocker.html', stock_id=趣股, stock=st, name=stock_name)
  今日=datetime.now().today()
  rndrCode(今日)
  for 股, 果 in 結果.items():

    股個=個股.get(股)
    if hasattr(果, 'values'):
      訊號, 價格=果.values()# 'pivot': 'Buy it: 量縮價不跌, 三日均價大於六日均價', 'price':
    rndrCode([f'{股}->{股個}', 訊號, 價格])
