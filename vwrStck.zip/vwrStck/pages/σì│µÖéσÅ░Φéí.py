#只能用在jupyter notebook裡
from stUtil import rndrCode
from twstock import Stock, realtime as 即時
from pandas import DataFrame
from datetime import datetime, date, timedelta
from streamlit import dataframe

趣股={'2330':'台積電', '1215':'群峰'}
from streamlit import sidebar, multiselect, radio as stRadio, text_input
#股欄=['股票代碼', '地區', '股票名稱', '公司全名','現在時間', '最新成交價', '成交量', '累計成交量', '最佳5檔賣出價', '最佳5檔賣出量', '最佳5檔買進價', '最佳5檔買進量', '開盤價', '最高價', '最低價']
股欄=['日期', '成交股數', '成交量', '開價', '高價', '低價', '收價', '漲跌價差', '交易量']
MENU, 表單=[], ['個股分析', '', '']	#, '錯綜複雜', '二十四節氣'
for ndx, Menu in enumerate(表單): MENU.append(f'{ndx}{Menu}')
with sidebar:
  menu=stRadio('表單', MENU, horizontal=True, index=0)
  欄股=multiselect('股市欄位', 股欄, default=股欄[0])
  srch=text_input('搜尋', '')
if menu==len(表單): #
  pass
elif menu==MENU[1]: #
  pass
elif menu==MENU[0]: #個股分析
  pass
  今日=datetime.today()
  昨日=今日-timedelta(days=-1)
  rndrCode(昨日.date())
  for 股碼 in 趣股:
    個股=Stock(股碼)
    #個股 = 即時.get(股碼) #檢查是不是即時資料 是:顯示True 不是:顯示False
    #個股
    股資=個股.fetch_31()
    #股資
    #rndrCode(股資)
    #rndrCode(個股['success'])
    資框 = DataFrame(股資, columns=股欄)#.T.iloc[1:3]
    rndrCode(f"{趣股.get(股碼)}")
    #資框.set_caption(f"{趣股.get(股碼)}")
    #資框
    資框.style.set_table_attributes("style='display:inline'").set_caption(f"{趣股.get(股碼)}")
    #資框.style.set_caption(f"{趣股.get(股碼)}")
    #資框.style.set_caption(f'{趣股.get(股碼)}').set_table_styles(styles)
    if 欄股:
      dataframe(資框[欄股])
    #date=datetime.datetime(2025, 4, 7, 0, 0), capacity=37652704, turnover=32012146992, open=848.0, high=848.0, low=848.0, close=848.0, change=-94.0, transaction=219438
    #result.columns =
    #result
