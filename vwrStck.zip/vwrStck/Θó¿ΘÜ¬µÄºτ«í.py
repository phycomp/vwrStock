from pandas import DataFrame
from twstock import Stock
from statsmodels.tsa.regime_switching.markov_regression import MarkovRegression
from sklearn.preprocessing import MinMaxScaler
from twstock import realtime as 即時
import websocket
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout

def 動態止損(股碼, entry_price, atr_period=14, risk_multiplier=2): #1. 動態止損/止盈
    # 使用 ATR（平均真實波幅）計算動態止損
    stock = Stock(股碼)
    historical_data = stock.fetch_from(2023, 1)  # 獲取歷史數據

    high = [d.high for d in historical_data]
    low = [d.low for d in historical_data]
    close = [d.close for d in historical_data]

    # 計算 ATR
    true_range = [max(h - l, abs(h - c_prev), abs(l - c_prev)) for h, l, c_prev in zip(high[1:], low[1:], close[:-1])]
    atr = sum(true_range[-atr_period:]) / atr_period

    stop_loss = entry_price - (atr * risk_multiplier) #動態止損位 = 進場價 ± ATR * 風險倍數
    take_profit = entry_price + (atr * risk_multiplier * 1.5)  # 止盈比例可調整
    return stop_loss, take_profit

def position_sizing(account_balance, stop_loss_distance, risk_per_trade=0.02):  #2. 倉位控制
    risk_amount = account_balance * risk_per_trade # 根據風險比例計算可買入股數
    shares = risk_amount / abs(stop_loss_distance)
    return int(shares)

#3. 風險評估指標

def evaluate_portfolio_risk(returns): # 夏普比率 (假設無風險利率為 0)
    sharpe_ratio = np.mean(returns) / np.std(returns)

    cumulative = np.cumsum(returns) # 最大回撤
    peak = np.maximum.accumulate(cumulative)
    drawdown = (peak - cumulative)
    max_drawdown = np.max(drawdown)

    return sharpe_ratio, max_drawdown

returns = [0.02, -0.01, 0.03, -0.02]  # 模擬報酬序列
sharpe, max_dd = evaluate_portfolio_risk(returns)
rndrCode(f"夏普比率: {sharpe:.2f}, 最大回撤: {max_dd:.2%}")

def prepare_ml_data(股碼, lookback=30):     #二、機器學習模型整合 1. 數據預處理
    stock = Stock(股碼) # 獲取歷史數據
    data = stock.fetch_from(2020, 1)

    # 構建特徵
    df = DataFrame({
        'close': [d.close for d in data],
        'volume': [d.capacity for d in data],  # 成交量
        'ma5': [d.close for d in data].rolling(5).mean(),
        'ma20': [d.close for d in data].rolling(20).mean(),
        'rsi': calculate_rsi(pd.Series([d.close for d in data]), 14)
    }).dropna()

    # 標籤：未來 5 日收益率
    df['future_5d_return'] = df['close'].pct_change(5).shift(-5)
    df['target'] = (df['future_5d_return'] > 0).astype(int)  # 二元分類問題

    # 標準化
    scaler = MinMaxScaler()
    scaled_features = scaler.fit_transform(df[['close', 'volume', 'ma5', 'ma20', 'rsi']])

    # 時間序列分割
    X = []
    y = []
    for i in range(len(df) - lookback -5):
        X.append(scaled_features[i:i+lookback])
        y.append(df['target'].iloc[i+lookback])

    return np.array(X), np.array(y), scaler

X, y, scaler = prepare_ml_data('2330')
#2. LSTM 模型範例 (使用 TensorFlow)

def build_lstm_model(input_shape):
    model = Sequential([
        LSTM(50, return_sequences=True, input_shape=input_shape),
        Dropout(0.2),
        LSTM(30),
        Dense(1, activation='sigmoid')
    ])
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    return model

model = build_lstm_model((X.shape[1], X.shape[2]))  # 訓練模型
model.fit(X, y, epochs=20, batch_size=32, validation_split=0.2)
#3. 模型預測整合交易
def 交易訊號(股碼, model, scaler, lookback=30):
    stock = Stock(股碼)
    latest_data = stock.fetch_from(2023, 1)[-lookback:]  # 假設即時更新 獲取最新數據

    # 特徵工程
    latest_features = pd.DataFrame({
        'close': [d.close for d in latest_data],
        'volume': [d.capacity for d in latest_data],
        'ma5': [d.close for d in latest_data].rolling(5).mean().values,
        'ma20': [d.close for d in latest_data].rolling(20).mean().values,
        'rsi': calculate_rsi(pd.Series([d.close for d in latest_data]), 14)
    }).dropna()

    # 標準化
    scaled_input = scaler.transform(latest_features)
    X_latest = scaled_input.reshape(1, lookback, -1)

    # 預測
    prediction = model.predict(X_latest)[0][0]
    return '買入' if prediction > 0.6 else '賣出' if prediction < 0.4 else '持有'

signal = 交易訊號('2330', model, scaler)
rndrCode(f"模型建議: {signal}")

def integrated_trading_system(股碼, account_balance): #三、整合決策系統
    即資 = 即時.get(股碼) # 獲取即時數據
    if not 即資['success']:
        return "數據獲取失敗"

    current_price = float(realtime_data['realtime']['latest_trade_price'])

    ml_signal = 交易訊號(股碼, model, scaler) # 機器學習信號

    ma_signal = moving_average_crossover_signal(股碼) # 技術指標信號

    # 風險評估
    stop_loss, take_profit = dynamic_stoploss(股碼, current_price)
    shares = position_sizing(account_balance, stop_loss_distance=current_price - stop_loss)

    # 綜合決策
    if ml_signal == '買入' and ma_signal == '買入':
        action = f"執行買入 {shares} 股，止損位: {stop_loss:.2f}"
    elif ml_signal == '賣出' or current_price < stop_loss:
        action = "執行賣出"
    else:
        action = "維持現狀"

    return action

rndrCode(integrated_trading_system('2330', 1000000))
#四、進階實作方向 強化學習應用 使用 Stable-Baselines3 實現 DQN 演算法，讓模型學習最大化夏普比率：

from stable_baselines3 import DQN

class StockTradingEnv(gym.Env):
    def __init__(self, data):
    # 自定義環境（包含價格數據、帳戶狀態、交易規則）
        self.data = data
        self.action_space = spaces.Discrete(3)  # 買/賣/持有
        self.observation_space = spaces.Box(low=0, high=1, shape=(6,))

    def step(self, action):
        # 實現狀態轉移與獎勵計算
        pass

model = DQN('MlpPolicy', env, verbose=1) # 訓練模型
model.learn(total_timesteps=10000)
#即時數據管道 使用 websocket 連接券商 API 獲取即時報價：

def on_message(ws, message):
    data = json.loads(message) # 解析即時數據並觸發策略
    price = data['price']
    if integrated_trading_system('2330', price) == "買入": # 串接下單 API
        place_order(symbol='2330', quantity=shares)

ws = websocket.WebSocketApp("wss://broker-api.com/stream", on_message=on_message)
ws.run_forever()
#模型監控與再訓練

from evidently.dashboard import Dashboard
from evidently.tabs import DataDriftTab

def monitor_data_drift(reference_data, current_data):
    data_drift_report = Dashboard(tabs=[DataDriftTab()])
    data_drift_report.calculate(reference_data, current_data)
    data_drift_report.save("reports/data_drift.html")
    # 若數據漂移過大，觸發模型再訓練

from keras.regularizers import l2
model.add(Dense(64, kernel_regularizer=l2(0.01)))

def backtest_with_costs(signals, initial_capital=1e6, fee_ratio=0.001425):
    positions = 0
    capital = initial_capital
    for signal, price in signals:
        if signal == 'buy' and capital > price:
            shares = capital // price
            capital -= shares * price * (1 + fee_ratio)
            positions += shares
        # 類似實現賣出邏輯...

model = MarkovRegression(df['return'], k_regimes=2)
result = model.fit()
df['regime'] = result.smoothed_marginal_probabilities[1] > 0.5

def liquidity_check(股碼, threshold=1000):
    realtime_data = twstock.realtime.get(股碼)
    volume = int(realtime_data['realtime']['accumulate_trade_volume'])
    return volume > threshold  # 例如成交量低於 1000 張不交易 此框架需結合實際市場特性持續優化，建議先進行 1~3 年的歷史數據回測
