class LSTMModel(torch.nn.Module):
    def __init__(self, input_size, hidden_size, num_layers=2):
        super().__init__()
        self.lstm = torch.nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=0.2
        )
        self.fc = torch.nn.Linear(hidden_size, 1)
        
    def forward(self, x):
        out, (hn, cn) = self.lstm(x)
        return self.fc(out[:, -1, :])

# 初始化參數
model = LSTMModel(input_size=4, hidden_size=64)
2. GRU 模型（速度優化）
class GRUModel(torch.nn.Module):
    def __init__(self, input_size, hidden_size, num_layers=2):
        super().__init__()
        self.gru = torch.nn.GRU(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=0.2
        )
        self.fc = torch.nn.Sequential(
            torch.nn.Linear(hidden_size, 32),
            torch.nn.ReLU(),
            torch.nn.Linear(32, 1)
        )
        
    def forward(self, x):
        out, hn = self.gru(x)
        return self.fc(out[:, -1, :])
3. Transformer 模型（捕捉長期依賴）
class TransformerModel(torch.nn.Module):
    def __init__(self, input_size, d_model=64, nhead=4):
        super().__init__()
        self.embedding = torch.nn.Linear(input_size, d_model)
        encoder_layer = torch.nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=128,
            dropout=0.1
        )
        self.transformer = torch.nn.TransformerEncoder(encoder_layer, num_layers=3)
        self.fc = torch.nn.Linear(d_model, 1)
        
    def forward(self, x):
        x = self.embedding(x)  # [batch, seq_len, d_model]
        x = x.permute(1, 0, 2)  # [seq_len, batch, d_model]
        out = self.transformer(x)
        return self.fc(out[-1, :, :])
4. 混合模型（CNN + LSTM）
class CNNLSTMModel(torch.nn.Module):
    def __init__(self, input_size, cnn_channels=32, lstm_hidden=64):
        super().__init__()
        self.cnn = torch.nn.Sequential(
            torch.nn.Conv1d(input_size, cnn_channels, kernel_size=3, padding=1),
            torch.nn.ReLU(),
            torch.nn.MaxPool1d(2)
        )
        self.lstm = torch.nn.LSTM(
            input_size=cnn_channels,
            hidden_size=lstm_hidden,
            batch_first=True
        )
        self.fc = torch.nn.Linear(lstm_hidden, 1)
        
    def forward(self, x):
        x = x.permute(0, 2, 1)  # [batch, features, seq_len]
        cnn_out = self.cnn(x)
        cnn_out = cnn_out.permute(0, 2, 1)  # [batch, seq_len/2, channels]
        lstm_out, _ = self.lstm(cnn_out)
        return self.fc(lstm_out[:, -1, :])
三、模型訓練與優化
1. 訓練流程模板
def train_model(model, dataloader, epochs=100, lr=0.001):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)
    
    criterion = torch.nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', patience=5)
    
    best_loss = float('inf')
    for epoch in range(epochs):
        model.train()
        train_loss = 0
        for inputs, labels in dataloader:
            inputs, labels = inputs.to(device), labels.to(device)
            
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)  # 梯度裁剪
            optimizer.step()
            
            train_loss += loss.item()
        
        avg_loss = train_loss / len(dataloader)
        scheduler.step(avg_loss)
        
        # Early Stopping
        if avg_loss < best_loss:
            best_loss = avg_loss
            torch.save(model.state_dict(), 'best_model.pth')
            patience_counter = 0
        else:
            patience_counter += 1
            if patience_counter >= 10:
                print(f"Early stopping at epoch {epoch}")
                break
        
        print(f"Epoch {epoch+1}/{epochs} | Loss: {avg_loss:.4f}")
2. 多模型對比訓練
models = {
    'LSTM': LSTMModel(input_size=4, hidden_size=64),
    'GRU': GRUModel(input_size=4, hidden_size=64),
    'Transformer': TransformerModel(input_size=4),
    'CNN-LSTM': CNNLSTMModel(input_size=4)
}

results = {}
for name, model in models.items():
    print(f"Training {name}...")
    train_model(model, dataloader)
    results[name] = evaluate_model(model, test_loader)  # 需實現評估函數
四、模型解釋與策略整合
1. 特征重要性分析（使用Captum）
from captum.attr import IntegratedGradients

def analyze_feature_importance(model, sample_input):
    ig = IntegratedGradients(model)
    attributions = ig.attribute(sample_input)
    
    # 可視化
    feature_names = ['close', 'volume', 'sox_pct', 'fx_impact']
    plt.barh(feature_names, attributions.mean(dim=1).squeeze().cpu().detach().numpy())
    plt.title("Feature Importance via Integrated Gradients")
2. 交易信號生成器
class TradingSignalGenerator:
    def __init__(self, model, scaler, threshold=0.03):
        self.model = model.eval()
        self.scaler = scaler
        self.threshold = threshold  # 價格波動阈值
        
    def generate_signal(self, latest_sequence):
        with torch.no_grad():
            prediction = self.model(latest_sequence)
            predicted_change = (prediction - latest_sequence[-1, 0].item()) / latest_sequence[-1, 0].item()
            
            if predicted_change > self.threshold:
                return 'BUY', predicted_change
            elif predicted_change < -self.threshold:
                return 'SELL', predicted_change
            else:
                return 'HOLD', predicted_change

# 使用示例
sequence = dataset[-1][0].unsqueeze(0)  # 獲取最新序列
generator = TradingSignalGenerator(model, dataset.scaler)
signal, confidence = generator.generate_signal(sequence)

